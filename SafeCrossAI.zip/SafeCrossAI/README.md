# SafeCross AI — مساعد عبور المشاة (Android)

Experimental pedestrian crossing assistant: live camera → on-device vehicle detection (TensorFlow Lite) → tracking →
conservative risk engine → Arabic-first warnings. **It never states that crossing is safe.** Read `docs/LIMITATIONS.md`.

## Status (honest)
* Source, unit tests and docs are complete and were statically checked (brace balance, imports, string tables).
* **Not compiled, not run, no APK produced**: the authoring sandbox had no network, Android SDK, Gradle or Kotlin compiler.
  The first build on your machine may reveal small compile errors; fix them, they will be mechanical.
* **No model file is bundled**: you must add it (`docs/MODEL.md`). Without it the app runs but stays in WAIT with a visible warning.
* Nothing has been validated on real roads.

## Architecture (package `com.safecross.ai`)
```
camera/       CameraX capture (Preview + ImageAnalysis), gyro stability, scene quality, thermal
detection/    VehicleDetector interface, TFLite EfficientDet detector, preprocessing, output decoding
tracking/     IoU tracker with motion prediction, least-squares image motion (looming, drift)
calibration/  road-plane homography, calibration state machine, metric (m, m/s) motion
risk/         ThreatAssessor (tracks -> threats), RiskEngine (pure), WarningSmoother, config
pipeline/     AnalysisPipeline orchestration + UI state, watchdog re-evaluation
settings/     DataStore settings (language, sound, vibration, confidence, road width, margin, zone)
permissions/  camera permission gate (explanation, permanent-denial -> app settings)
feedback/     optional sound / vibration
ui/           Compose screens (RTL), strings (ar/en), view model
```
Key safety rules implemented in `RiskEngine` (unit-tested): image-only estimates never yield "no clear danger" for an
approaching vehicle; unknown/unconfirmed/lost/stale data is never clear; perception problems force WAIT but never hide DANGER;
DANGER escalates instantly, de-escalation is delayed (`WarningSmoother`); a frozen camera degrades to WAIT via a 250 ms watchdog.

## Build
Requirements: JDK 17, Android SDK platform 35 + build-tools, internet for Gradle. See `scripts/check_env.sh`.
```
gradle wrapper --gradle-version 8.11.1      # once: generates gradlew (or just open the folder in Android Studio)
./gradlew :app:testDebugUnitTest            # unit tests
./gradlew :app:assembleDebug                # APK -> app/build/outputs/apk/debug/app-debug.apk
./gradlew :app:connectedDebugAndroidTest    # instrumentation test (device/emulator)
```
## Run on a phone
1. Add the model (docs/MODEL.md). 2. Enable Developer options → USB debugging. 3. `adb install -r app/build/outputs/apk/debug/app-debug.apk`
(or Run from Android Studio). 4. Grant camera permission. 5. Use a tripod/mount for calibration; test only with recorded footage first
(`docs/TESTING_PROTOCOL.md`).

## Privacy
Manifest permissions: `CAMERA`, `VIBRATE` only. No INTERNET, no location, no analytics/ads, no video storage. Settings are the only persisted data;
calibration is never persisted.

## Implemented
Live preview + overlay (boxes, IDs, class, motion, zone) · permission flow · TFLite detector with strict model validation ·
tracker · image-space motion/looming TTC · road-plane calibration (4 taps + measured size, gyro-validated) · metric speed/TTC with
uncertainty only when calibrated · risk engine with 3 states and exact Arabic labels · smoothing · analysis-status chips ·
sound/vibration toggles · Arabic RTL + English · settings screen · unit tests (risk, smoother, tracker, calibration, assessor,
decoding, settings, UI text) + instrumentation test for the model contract.

## Needs real-world validation
See the last section of `docs/LIMITATIONS.md`.
