package com.safecross.ai

import android.graphics.Bitmap
import android.graphics.Color
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.safecross.ai.detection.DetectorInput
import com.safecross.ai.detection.ModelUnavailableException
import com.safecross.ai.detection.TfliteVehicleDetector
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Runs on a device/emulator. Verifies the model integration contract:
 *  - without the model file the detector is NOT ready, explains why, and throws instead of faking output;
 *  - with the model file, a blank frame runs end-to-end with plausible output (no vehicles in a grey image).
 * Real detection quality must be checked with recorded footage (docs/TESTING_PROTOCOL.md).
 */
@RunWith(AndroidJUnit4::class)
class DetectorInstrumentedTest {
    private val context = InstrumentationRegistry.getInstrumentation().targetContext
    private fun modelPresent() = context.assets.list("")?.contains(TfliteVehicleDetector.DEFAULT_MODEL_ASSET) == true
    private fun grey() = Bitmap.createBitmap(640, 480, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.GRAY) }

    @Test fun missingModelNeverProducesFakeDetections() {
        assumeTrue(!modelPresent())
        val d = TfliteVehicleDetector(context)
        assertFalse(d.isReady)
        assertNotNull(d.unavailableReason)
        try {
            d.detect(DetectorInput(grey(), 90, 0))
            throw AssertionError("detect() must throw when the model is missing")
        } catch (e: ModelUnavailableException) { /* expected */ }
    }

    @Test fun presentModelRunsOnBlankFrame() {
        assumeTrue(modelPresent())
        val d = TfliteVehicleDetector(context)
        assertTrue(d.unavailableReason, d.isReady)
        val out = d.detect(DetectorInput(grey(), 90, 0))
        assertTrue("a flat grey image should not contain confident vehicles", out.size <= 1)
        d.close()
    }
}
