package com.safecross.ai.risk

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RiskConfigTest {
    @Test fun defaultCrossingTimeIsConservative() {
        val c = RiskConfig()
        assertEquals(12.0, c.crossingDurationS, 1e-9)   // (2 + 8 / 1.0) * 1.2
        assertEquals(15.0, c.requiredClearTimeS, 1e-9)  // + 3 s margin
    }

    @Test fun widerRoadOrSlowerWalkingRaisesRequiredTime() {
        val base = RiskConfig().requiredClearTimeS
        assertTrue(RiskConfig(crossingWidthM = 12.0).requiredClearTimeS > base)
        assertEquals(RiskConfig(walkingSpeedMps = 0.5).requiredClearTimeS, (2.0 + 16.0) * 1.2 + 3.0, 1e-9)
    }

    @Test fun invalidParametersAreRejected() {
        listOf<() -> RiskConfig>(
            { RiskConfig(crossingWidthM = 0.0) },
            { RiskConfig(walkingSpeedMps = 0.0) },
            { RiskConfig(safetyMarginS = -1.0) },
        ).forEach { make ->
            try { make(); throw AssertionError("expected IllegalArgumentException") } catch (e: IllegalArgumentException) { /* expected */ }
        }
    }
}
