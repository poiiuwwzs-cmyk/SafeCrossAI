package com.safecross.ai.settings

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AppSettingsTest {
    @Test fun defaultsAreArabicAndConservative() {
        val s = AppSettings()
        assertEquals(AppLanguage.ARABIC, s.language)
        assertEquals(15.0, s.toRiskConfig().requiredClearTimeS, 1e-9)
    }

    @Test fun unsafeValuesAreClampedToConservativeLimits() {
        val s = AppSettings(walkingSpeedMps = 3.0f, safetyMarginS = 0f, crossingWidthM = 0f, minConfidence = 0f).sanitized()
        assertEquals(1.4f, s.walkingSpeedMps, 1e-6f)  // never running speed
        assertEquals(2f, s.safetyMarginS, 1e-6f)      // never less than 2 s margin
        assertEquals(2f, s.crossingWidthM, 1e-6f)
        assertEquals(0.2f, s.minConfidence, 1e-6f)
    }

    @Test fun invalidZoneIsRepaired() {
        val z = AppSettings(zoneLeft = 0.9f, zoneRight = 0.1f, zoneTop = 2f).toZone()
        assertTrue(z.left < z.right)
        assertEquals(0.95f, z.top, 1e-6f)
    }
}
