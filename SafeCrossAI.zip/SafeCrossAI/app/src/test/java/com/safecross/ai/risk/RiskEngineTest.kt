package com.safecross.ai.risk

import com.safecross.ai.detection.VehicleClass
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RiskEngineTest {
    private val engine = RiskEngine()
    private val config = RiskConfig() // required clear time = 15 s

    private fun healthy(ageMs: Long = 0) = PerceptionHealth(
        modelReady = true, lastFrameAgeMs = ageMs, inferenceLatencyMs = 80, cameraStable = true,
        sceneQuality = SceneQuality.OK, thermalSevere = false, trackingFailed = false,
    )

    private fun threat(
        id: Int = 1,
        motion: MotionClass = MotionClass.APPROACHING,
        inZone: Boolean = false,
        lost: Boolean = false,
        confirmed: Boolean = true,
        ttc: TimeToConflict? = null,
    ) = ThreatInput(id, VehicleClass.CAR, motion, inZone, lost, confirmed, ttc, null)

    private fun calibrated(lower: Double) = TimeToConflict.of(lower + 5, lower, TtcBasis.CALIBRATED_METRIC)
    private fun imageOnly(lower: Double) = TimeToConflict.of(lower + 5, lower, TtcBasis.IMAGE_SCALE_TAU)

    private fun run(threats: List<ThreatInput>, health: PerceptionHealth = healthy(), cfg: RiskConfig = config) =
        engine.evaluate(RiskInput(threats, health), cfg)

    // ---- basics -----------------------------------------------------------------------------------------
    @Test fun noVehiclesAndHealthyScene_isPotentiallyClear() {
        assertEquals(RiskState.POTENTIALLY_CLEAR, run(emptyList()).state)
    }

    @Test fun noFrameAnalysedYet_isNeverClear() {
        val r = run(emptyList(), healthy(PerceptionHealth.NO_FRAME_YET_MS))
        assertEquals(RiskState.UNCERTAIN, r.state)
        assertTrue(HealthIssue.NO_RECENT_FRAME in r.issues)
    }

    // ---- time to conflict vs safety margin --------------------------------------------------------------
    @Test fun calibratedApproachBelowRequiredTime_isDanger() {
        val r = run(listOf(threat(ttc = calibrated(10.0))))
        assertEquals(RiskState.DANGER, r.state)
        assertEquals(RiskReason.BELOW_SAFETY_MARGIN, r.dominant?.reason)
    }

    @Test fun calibratedApproachFarAway_isPotentiallyClear() {
        assertEquals(RiskState.POTENTIALLY_CLEAR, run(listOf(threat(ttc = calibrated(30.0)))).state)
    }

    @Test fun boundaryExactlyAtRequiredTime_isNotDanger_andJustBelowIs() {
        assertEquals(RiskState.POTENTIALLY_CLEAR, run(listOf(threat(ttc = calibrated(15.0)))).state)
        assertEquals(RiskState.DANGER, run(listOf(threat(ttc = calibrated(14.9)))).state)
    }

    @Test fun largerSafetyMarginTurnsClearIntoDanger() {
        val t = listOf(threat(ttc = calibrated(16.0)))
        assertEquals(RiskState.POTENTIALLY_CLEAR, run(t).state)
        assertEquals(RiskState.DANGER, run(t, cfg = RiskConfig(safetyMarginS = 5.0)).state)
    }

    @Test fun imageOnlyEstimateNeverClears_evenWhenFarAway() {
        val r = run(listOf(threat(ttc = imageOnly(60.0))))
        assertEquals(RiskState.UNCERTAIN, r.state)
        assertTrue(r.calibrationMissingForDecision)
    }

    @Test fun imageOnlyEstimateBelowMargin_isStillDanger() {
        assertEquals(RiskState.DANGER, run(listOf(threat(ttc = imageOnly(5.0)))).state)
    }

    @Test fun approachingInZoneWithUnknownTtc_isDanger_outsideIsUncertain() {
        assertEquals(RiskState.DANGER, run(listOf(threat(inZone = true, ttc = null))).state)
        assertEquals(RiskState.UNCERTAIN, run(listOf(threat(inZone = false, ttc = null))).state)
    }

    @Test fun staleFrameShrinksTheTimeToConflict() {
        // 16 s lower bound is fine with a fresh frame, but a 2 s old frame leaves only 14 s < 15 s.
        val t = listOf(threat(ttc = calibrated(16.0)))
        assertEquals(RiskState.POTENTIALLY_CLEAR, run(t, healthy(0)).state)
        assertEquals(RiskState.DANGER, run(t, healthy(2000)).state)
    }

    // ---- other vehicle situations -----------------------------------------------------------------------
    @Test fun vehicleMovingAway_isIgnored() {
        val r = run(listOf(threat(motion = MotionClass.RECEDING, inZone = true)))
        assertEquals(RiskState.POTENTIALLY_CLEAR, r.state)
        assertTrue(r.evaluations.isEmpty())
    }

    @Test fun stationaryVehicle_inZoneIsUncertain_outsideIsIgnored() {
        assertEquals(RiskState.UNCERTAIN, run(listOf(threat(motion = MotionClass.STATIONARY, inZone = true))).state)
        assertEquals(RiskState.POTENTIALLY_CLEAR, run(listOf(threat(motion = MotionClass.STATIONARY, inZone = false))).state)
    }

    @Test fun unknownMotion_isUncertain() {
        assertEquals(RiskState.UNCERTAIN, run(listOf(threat(motion = MotionClass.UNKNOWN))).state)
    }

    @Test fun unconfirmedTrack_inZoneIsUncertain_outsideIgnored() {
        assertEquals(RiskState.UNCERTAIN, run(listOf(threat(confirmed = false, inZone = true))).state)
        assertEquals(RiskState.POTENTIALLY_CLEAR, run(listOf(threat(confirmed = false, inZone = false))).state)
    }

    // ---- tracking loss ----------------------------------------------------------------------------------
    @Test fun lostApproachingTrack_isDanger() {
        val r = run(listOf(threat(lost = true, ttc = calibrated(60.0))))
        assertEquals(RiskState.DANGER, r.state)
        assertEquals(RiskReason.LOST_APPROACHING_TRACK, r.dominant?.reason)
    }

    @Test fun lostTrack_otherCases() {
        assertEquals(RiskState.UNCERTAIN, run(listOf(threat(lost = true, motion = MotionClass.UNKNOWN))).state)
        assertEquals(RiskState.UNCERTAIN, run(listOf(threat(lost = true, motion = MotionClass.STATIONARY, inZone = true))).state)
        assertEquals(RiskState.POTENTIALLY_CLEAR, run(listOf(threat(lost = true, motion = MotionClass.STATIONARY, inZone = false))).state)
        assertEquals(RiskState.POTENTIALLY_CLEAR, run(listOf(threat(lost = true, motion = MotionClass.RECEDING))).state)
    }

    // ---- several vehicles -------------------------------------------------------------------------------
    @Test fun mostDangerousVehicleDecides() {
        val r = run(listOf(
            threat(id = 1, ttc = calibrated(40.0)),
            threat(id = 2, ttc = calibrated(5.0)),
            threat(id = 3, ttc = calibrated(10.0)),
            threat(id = 4, motion = MotionClass.RECEDING),
        ))
        assertEquals(RiskState.DANGER, r.state)
        assertEquals(2, r.dominant?.threat?.trackId)
    }

    @Test fun safeVehicleDoesNotMaskUncertainOne() {
        val r = run(listOf(threat(id = 1, ttc = calibrated(40.0)), threat(id = 2, motion = MotionClass.UNKNOWN)))
        assertEquals(RiskState.UNCERTAIN, r.state)
    }

    // ---- perception health ------------------------------------------------------------------------------
    @Test fun everyHealthIssueForcesUncertain() {
        val cases = listOf(
            healthy().copy(modelReady = false) to HealthIssue.MODEL_UNAVAILABLE,
            healthy().copy(lastFrameAgeMs = 701) to HealthIssue.NO_RECENT_FRAME,
            healthy().copy(inferenceLatencyMs = 601) to HealthIssue.ANALYSIS_SLOW,
            healthy().copy(cameraStable = false) to HealthIssue.CAMERA_UNSTABLE,
            healthy().copy(sceneQuality = SceneQuality.TOO_DARK) to HealthIssue.TOO_DARK,
            healthy().copy(sceneQuality = SceneQuality.TOO_BRIGHT) to HealthIssue.TOO_BRIGHT,
            healthy().copy(sceneQuality = SceneQuality.BLURRY) to HealthIssue.BLURRY,
            healthy().copy(thermalSevere = true) to HealthIssue.THERMAL_THROTTLING,
            healthy().copy(trackingFailed = true) to HealthIssue.TRACKING_FAILURE,
        )
        for ((health, issue) in cases) {
            val r = run(emptyList(), health)
            assertEquals("for $issue", RiskState.UNCERTAIN, r.state)
            assertTrue("for $issue", issue in r.issues)
        }
    }

    @Test fun healthProblemNeverHidesImmediateDanger() {
        val r = run(listOf(threat(ttc = calibrated(3.0))), healthy().copy(sceneQuality = SceneQuality.BLURRY, trackingFailed = true))
        assertEquals(RiskState.DANGER, r.state)
    }

    // ---- invariant sweep: no false "clear" ----------------------------------------------------------------
    @Test fun neverClearWhenAnyRelevantVehicleIsUnverified() {
        val ttcs = listOf(null, imageOnly(30.0), calibrated(30.0), calibrated(5.0))
        var checked = 0
        for (motion in MotionClass.values()) for (lost in listOf(false, true)) for (confirmed in listOf(false, true))
            for (inZone in listOf(false, true)) for (ttc in ttcs) {
                val t = threat(motion = motion, lost = lost, confirmed = confirmed, inZone = inZone, ttc = ttc)
                val state = run(listOf(t)).state
                checked++
                if (state == RiskState.POTENTIALLY_CLEAR) {
                    val label = "motion=$motion lost=$lost confirmed=$confirmed inZone=$inZone ttc=$ttc"
                    // allowed only for: unconfirmed outside zone, receding, stationary outside zone, or calibrated safe approach
                    val allowed = (!confirmed && !inZone) ||
                        (confirmed && motion == MotionClass.RECEDING) ||
                        (confirmed && motion == MotionClass.STATIONARY && !inZone) ||
                        (confirmed && !lost && motion == MotionClass.APPROACHING && ttc != null && ttc.basis == TtcBasis.CALIBRATED_METRIC && ttc.lowerBoundS >= 15.0)
                    assertTrue("false clear: $label", allowed)
                }
            }
        assertEquals(4 * 2 * 2 * 2 * 4, checked)
    }

    @Test fun assessmentReportsRequiredTime() {
        val r = run(emptyList())
        assertEquals(15.0, r.requiredClearTimeS, 1e-9)
        assertNotNull(r)
        assertFalse(r.calibrationMissingForDecision)
    }
}
