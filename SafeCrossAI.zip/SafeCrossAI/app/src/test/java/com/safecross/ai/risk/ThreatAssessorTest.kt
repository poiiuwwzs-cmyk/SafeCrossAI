package com.safecross.ai.risk

import com.safecross.ai.calibration.CalibrationResult
import com.safecross.ai.calibration.Point2
import com.safecross.ai.calibration.RoadPlaneCalibration
import com.safecross.ai.detection.Detection
import com.safecross.ai.detection.NormBox
import com.safecross.ai.detection.VehicleClass
import com.safecross.ai.tracking.VehicleTracker
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.exp

class ThreatAssessorTest {
    private val assessor = ThreatAssessor()
    private val zone = ConflictZone(left = 0.4f, right = 0.6f, top = 0.75f)

    private fun box(cx: Float, bottom: Float, h: Float, aspect: Float = 1.5f): NormBox {
        val w = h * aspect
        return NormBox(cx - w / 2, bottom - h, cx + w / 2, bottom)
    }

    /** Feeds one detection per 100 ms for [frames] frames and returns the tracker plus the time of the last frame. */
    private fun simulate(frames: Int, boxAt: (Int) -> NormBox): Pair<VehicleTracker, Long> {
        val tr = VehicleTracker()
        var t = 1000L
        for (i in 0 until frames) {
            tr.update(listOf(Detection(boxAt(i), VehicleClass.CAR, 0.9f)), t)
            if (i < frames - 1) t += 100
        }
        return tr to t
    }

    private fun assess(tr: VehicleTracker, now: Long, cal: RoadPlaneCalibration? = null, z: ConflictZone = zone) =
        assessor.assess(tr.activeTracks, z, cal, now, tr.params).single()

    @Test fun growingBox_isApproaching_withLoomingTau() {
        val (tr, now) = simulate(21) { i -> box(0.5f, 0.6f, 0.10f * exp(0.15f * i * 0.1f)) }
        val t = assess(tr, now)
        assertEquals(MotionClass.APPROACHING, t.motion)
        val ttc = t.ttc
        assertNotNull(ttc)
        assertEquals(TtcBasis.IMAGE_SCALE_TAU, ttc!!.basis)
        assertEquals(6.67, ttc.nominalS, 0.8)
        assertTrue(ttc.lowerBoundS < ttc.nominalS)
        assertNull("image-only motion must never produce a speed", t.speed)
    }

    @Test fun shrinkingBox_isReceding() {
        val (tr, now) = simulate(21) { i -> box(0.5f, 0.6f, 0.20f * exp(-0.15f * i * 0.1f)) }
        assertEquals(MotionClass.RECEDING, assess(tr, now).motion)
    }

    @Test fun constantBox_isStationary_andInZoneFlagFollowsPosition() {
        val (tr1, n1) = simulate(21) { box(0.5f, 0.6f, 0.2f) }
        val a = assess(tr1, n1)
        assertEquals(MotionClass.STATIONARY, a.motion)
        assertEquals(false, a.inOrOverlapsZone)
        val (tr2, n2) = simulate(21) { box(0.5f, 0.9f, 0.2f) }
        val b = assess(tr2, n2)
        assertEquals(MotionClass.STATIONARY, b.motion)
        assertEquals(true, b.inOrOverlapsZone)
    }

    @Test fun lateralMovementTowardZone_isApproaching_withLateralTtc() {
        val (tr, now) = simulate(21) { i -> box(0.10f + 0.01f * i, 0.7f, 0.10f) } // 0.1 frame-widths / s
        val t = assess(tr, now)
        assertEquals(MotionClass.APPROACHING, t.motion)
        assertEquals(TtcBasis.IMAGE_LATERAL, t.ttc!!.basis)
        assertTrue(t.ttc!!.lowerBoundS < t.ttc!!.nominalS)
    }

    @Test fun lateralMovementAwayFromZone_isReceding() {
        val (tr, now) = simulate(21) { i -> box(0.30f - 0.01f * i, 0.7f, 0.10f) }
        assertEquals(MotionClass.RECEDING, assess(tr, now).motion)
    }

    @Test fun tooLittleHistory_isUnknown() {
        val (tr, now) = simulate(2) { box(0.5f, 0.6f, 0.1f) }
        val t = assess(tr, now)
        assertEquals(MotionClass.UNKNOWN, t.motion)
        assertNull(t.ttc)
    }

    @Test fun vehicleNotSeenForAWhile_isMarkedLost_andKeepsLastMotion() {
        val (tr, now) = simulate(21) { i -> box(0.5f, 0.6f, 0.10f * exp(0.15f * i * 0.1f)) }
        val t = assess(tr, now + 800)
        assertTrue(t.isLost)
        assertEquals(MotionClass.APPROACHING, t.motion)
    }

    // ---- calibrated metric motion ------------------------------------------------------------------------
    private val calibration: RoadPlaneCalibration by lazy {
        val pts = listOf(Point2(0.2, 0.9), Point2(0.8, 0.9), Point2(0.65, 0.5), Point2(0.35, 0.5))
        (RoadPlaneCalibration.create(pts, widthM = 8.0, lengthM = 30.0, nowMs = 0) as CalibrationResult.Success).calibration
    }

    private fun worldBox(x: Double, y: Double): NormBox {
        val p = calibration.worldToImage(x, y)!!
        val u = p.x.toFloat(); val v = p.y.toFloat()
        return NormBox(u - 0.04f, v - 0.08f, u + 0.04f, v)
    }

    @Test fun calibratedApproach_givesSpeedAndMetricTtc() {
        // Vehicle 4 m from the road edge, 10 m/s toward the crossing line, from 60 m to 45 m.
        val (tr, now) = simulate(16) { i -> worldBox(4.0, 60.0 - 10.0 * (i * 0.1)) }
        val t = assess(tr, now, calibration)
        assertEquals(MotionClass.APPROACHING, t.motion)
        assertEquals(TtcBasis.CALIBRATED_METRIC, t.ttc!!.basis)
        assertEquals(4.5, t.ttc!!.nominalS, 0.3)
        assertTrue(t.ttc!!.lowerBoundS < t.ttc!!.nominalS)
        assertNotNull(t.speed)
        assertEquals(36.0, t.speed!!.kmh, 2.0)
        assertTrue("speed must carry an uncertainty", t.speed!!.uncertaintyKmh > 1.0)
        assertEquals(false, t.inOrOverlapsZone)
    }

    @Test fun sameMotionWithoutCalibration_neverGivesSpeedOrMetricTtc() {
        val (tr, now) = simulate(16) { i -> worldBox(4.0, 60.0 - 10.0 * (i * 0.1)) }
        val t = assess(tr, now, cal = null)
        assertNull(t.speed)
        assertTrue(t.ttc == null || t.ttc!!.basis != TtcBasis.CALIBRATED_METRIC)
    }

    @Test fun vehicleFarOutsideCalibratedRegion_getsNoMetricNumbers() {
        val (tr, now) = simulate(16) { i -> worldBox(4.0, 200.0 - 10.0 * (i * 0.1)) } // 200 m > 3 * 30 m
        val t = assess(tr, now, calibration)
        assertNull(t.speed)
        assertTrue(t.ttc == null || t.ttc!!.basis != TtcBasis.CALIBRATED_METRIC)
    }

    @Test fun calibratedVehicleMovingAway_isReceding() {
        val (tr, now) = simulate(16) { i -> worldBox(4.0, 20.0 + 8.0 * (i * 0.1)) }
        assertEquals(MotionClass.RECEDING, assess(tr, now, calibration).motion)
    }

    @Test fun calibratedStationaryVehicle_isStationary() {
        val (tr, now) = simulate(16) { worldBox(4.0, 20.0) }
        assertEquals(MotionClass.STATIONARY, assess(tr, now, calibration).motion)
    }

    @Test fun endToEnd_fastCalibratedApproachBecomesDanger() {
        val (tr, now) = simulate(16) { i -> worldBox(4.0, 60.0 - 10.0 * (i * 0.1)) }
        val threats = assessor.assess(tr.activeTracks, zone, calibration, now, tr.params)
        val health = PerceptionHealth(true, 0, 80, true, SceneQuality.OK, false, false)
        assertEquals(RiskState.DANGER, RiskEngine().evaluate(RiskInput(threats, health), RiskConfig()).state)
    }
}
