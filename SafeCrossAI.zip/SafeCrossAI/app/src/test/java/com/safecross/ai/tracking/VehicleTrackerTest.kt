package com.safecross.ai.tracking

import com.safecross.ai.detection.Detection
import com.safecross.ai.detection.NormBox
import com.safecross.ai.detection.VehicleClass
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class VehicleTrackerTest {
    private fun det(cx: Float, bottom: Float = 0.6f, h: Float = 0.1f, cls: VehicleClass = VehicleClass.CAR, conf: Float = 0.9f): Detection {
        val w = h * 1.5f
        return Detection(NormBox(cx - w / 2, bottom - h, cx + w / 2, bottom), cls, conf)
    }

    @Test fun singleVehicleKeepsItsIdAndGetsConfirmed() {
        val tr = VehicleTracker()
        var t = 1000L
        repeat(10) { i ->
            tr.update(listOf(det(0.3f + 0.01f * i)), t)
            t += 100
        }
        val tracks = tr.activeTracks
        assertEquals(1, tracks.size)
        assertEquals(1, tracks[0].id)
        assertEquals(10, tracks[0].hits)
        assertTrue(tr.isConfirmed(tracks[0]))
    }

    @Test fun trackIsNotConfirmedBeforeMinHits() {
        val tr = VehicleTracker()
        tr.update(listOf(det(0.5f)), 0); tr.update(listOf(det(0.5f)), 100)
        assertFalse(tr.isConfirmed(tr.activeTracks[0]))
        tr.update(listOf(det(0.5f)), 200)
        assertTrue(tr.isConfirmed(tr.activeTracks[0]))
    }

    @Test fun twoSeparatedVehiclesKeepDistinctIds() {
        val tr = VehicleTracker()
        var t = 0L
        repeat(15) { i ->
            tr.update(listOf(det(0.2f + 0.005f * i), det(0.8f - 0.005f * i)), t)
            t += 100
        }
        assertEquals(2, tr.activeTracks.size)
        val left = tr.activeTracks.minByOrNull { it.lastBox.centerX }!!
        val right = tr.activeTracks.maxByOrNull { it.lastBox.centerX }!!
        assertEquals(1, left.id)
        assertEquals(2, right.id)
        assertEquals(15, left.hits)
        assertEquals(15, right.hits)
    }

    @Test fun unmatchedConfirmedTrackBecomesLostThenIsDropped() {
        val tr = VehicleTracker()
        repeat(5) { i -> tr.update(listOf(det(0.5f)), i * 100L) }
        val last = 400L
        tr.update(emptyList(), last + 300)
        assertEquals(1, tr.activeTracks.size)
        assertFalse(tr.isLost(tr.activeTracks[0], last + 300))
        tr.update(emptyList(), last + 500)
        assertTrue(tr.isLost(tr.activeTracks[0], last + 500))
        tr.update(emptyList(), last + 2001)
        assertTrue(tr.activeTracks.isEmpty())
    }

    @Test fun tentativeTrackIsDroppedQuickly() {
        val tr = VehicleTracker()
        tr.update(listOf(det(0.5f)), 0)
        tr.update(emptyList(), 600)
        assertTrue(tr.activeTracks.isEmpty())
    }

    @Test fun detectionFarFromAnyTrackStartsNewTrack() {
        val tr = VehicleTracker()
        repeat(4) { i -> tr.update(listOf(det(0.2f)), i * 100L) }
        tr.update(listOf(det(0.2f), det(0.8f)), 400)
        assertEquals(2, tr.activeTracks.size)
        assertEquals(setOf(1, 2), tr.activeTracks.map { it.id }.toSet())
    }

    @Test fun historyIsBounded() {
        val tr = VehicleTracker(TrackerParams(maxHistory = 60))
        repeat(300) { i -> tr.update(listOf(det(0.5f)), i * 50L) }
        assertEquals(60, tr.activeTracks[0].history.size)
    }

    @Test fun classIsMajorityVote() {
        val tr = VehicleTracker()
        val classes = listOf(VehicleClass.TRUCK, VehicleClass.CAR, VehicleClass.CAR, VehicleClass.CAR, VehicleClass.TRUCK)
        classes.forEachIndexed { i, c -> tr.update(listOf(det(0.5f, cls = c)), i * 100L) }
        assertEquals(VehicleClass.CAR, tr.activeTracks[0].vehicleClass)
    }

    @Test fun resetClearsEverything() {
        val tr = VehicleTracker()
        tr.update(listOf(det(0.5f)), 0)
        tr.reset()
        assertTrue(tr.activeTracks.isEmpty())
        tr.update(listOf(det(0.5f)), 0)
        assertEquals(1, tr.activeTracks[0].id)
    }

    @Test fun motionIsNullUntilEnoughHistory_thenAvailable() {
        val tr = VehicleTracker()
        repeat(3) { i -> tr.update(listOf(det(0.3f + 0.02f * i)), i * 100L) }
        assertNull(tr.activeTracks[0].imageMotion)
        repeat(10) { i -> tr.update(listOf(det(0.36f + 0.02f * i)), 300L + i * 100L) }
        val m = tr.activeTracks[0].imageMotion
        assertNotNull(m)
        assertEquals(0.2, m!!.vx, 0.02) // 0.02 per 100 ms = 0.2 frame-widths per second
    }

    @Test fun linearFit_recoversSlopeAndRejectsTinySamples() {
        val t = doubleArrayOf(0.0, 1.0, 2.0, 3.0, 4.0)
        val y = DoubleArray(5) { 2.0 + 3.0 * t[it] }
        val f = LinearFit.fit(t, y)!!
        assertEquals(3.0, f.slope, 1e-9)
        assertEquals(2.0, f.intercept, 1e-9)
        assertEquals(0.0, f.slopeSigma, 1e-9)
        assertNull(LinearFit.fit(doubleArrayOf(0.0, 1.0, 2.0), doubleArrayOf(0.0, 1.0, 2.0)))
        assertNull(LinearFit.fit(DoubleArray(5) { 1.0 }, DoubleArray(5) { it.toDouble() })) // degenerate time axis
    }

    @Test fun normBoxIou() {
        val a = NormBox(0f, 0f, 0.2f, 0.2f)
        assertEquals(1f, a.iou(a), 1e-6f)
        assertEquals(0f, a.iou(NormBox(0.5f, 0.5f, 0.7f, 0.7f)), 1e-6f)
        assertEquals(1f / 3f, a.iou(NormBox(0.1f, 0f, 0.3f, 0.2f)), 1e-4f) // half overlap -> 1/3
    }
}
