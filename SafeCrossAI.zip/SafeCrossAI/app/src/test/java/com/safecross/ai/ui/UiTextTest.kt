package com.safecross.ai.ui

import com.safecross.ai.calibration.CalibrationStatus
import com.safecross.ai.risk.RiskState
import com.safecross.ai.risk.SpeedEstimate
import com.safecross.ai.risk.TimeToConflict
import com.safecross.ai.risk.TtcBasis
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class UiTextTest {
    @Test fun parsesArabicIndicDigitsAndSeparators() {
        assertEquals(8.5, parseDecimal("٨٫٥")!!, 1e-9)
        assertEquals(8.5, parseDecimal("8,5")!!, 1e-9)
        assertEquals(30.0, parseDecimal(" 30 ")!!, 1e-9)
        assertNull(parseDecimal(""))
        assertNull(parseDecimal("abc"))
        assertNull(parseDecimal("Infinity"))
    }

    @Test fun requiredArabicLabelsAreExact() {
        assertEquals("خطر — لا تعبر الآن", ArabicStrings.riskLabel(RiskState.DANGER))
        assertEquals("غير واضح — انتظر وتأكد بنفسك", ArabicStrings.riskLabel(RiskState.UNCERTAIN))
        assertEquals("لم يُرصد خطر واضح — تأكد من خلو الطريق بنفسك", ArabicStrings.riskLabel(RiskState.POTENTIALLY_CLEAR))
        assertEquals("المعايرة غير مكتملة — لا يمكن تأكيد السرعة الحقيقية", ArabicStrings.calibrationMissing)
        assertEquals("تعذّر تحليل حركة السيارات — لا تعتمد على التقدير", ArabicStrings.trackingFailure)
        assertEquals("السرعة الحقيقية غير متاحة", ArabicStrings.speedUnavailable)
    }

    @Test fun speedIsNeverShownWithoutValidCalibration() {
        val speed = SpeedEstimate(42.0, 8.0)
        for (status in CalibrationStatus.values()) {
            val text = ArabicStrings.speedText(speed, status)
            if (status == CalibrationStatus.CALIBRATED) assertTrue(text.contains("42")) else assertEquals(ArabicStrings.speedUnavailable, text)
        }
        assertEquals(ArabicStrings.speedUnavailable, ArabicStrings.speedText(null, CalibrationStatus.CALIBRATED))
    }

    @Test fun imageOnlyTimeIsLabelledAsUncalibrated() {
        val image = ArabicStrings.ttcText(TimeToConflict.of(6.0, 4.0, TtcBasis.IMAGE_SCALE_TAU), true)
        val metric = ArabicStrings.ttcText(TimeToConflict.of(6.0, 4.0, TtcBasis.CALIBRATED_METRIC), true)
        assertTrue(image.contains(ArabicStrings.ttcImageBased))
        assertFalse(metric.contains(ArabicStrings.ttcImageBased))
    }

    @Test fun clearLabelNeverClaimsSafety() {
        for (s in listOf(ArabicStrings, EnglishStrings)) {
            assertFalse(s.clear.contains("آمن"))
            assertFalse(s.clear.lowercase().contains("safe to"))
        }
    }
}
