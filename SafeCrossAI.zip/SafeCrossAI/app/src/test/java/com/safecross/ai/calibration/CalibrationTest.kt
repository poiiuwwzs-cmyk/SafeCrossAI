package com.safecross.ai.calibration

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CalibrationTest {
    private val goodPoints = listOf(Point2(0.2, 0.9), Point2(0.8, 0.9), Point2(0.65, 0.5), Point2(0.35, 0.5))

    private fun create(pts: List<Point2> = goodPoints, w: Double = 8.0, l: Double = 30.0) =
        RoadPlaneCalibration.create(pts, w, l, nowMs = 0)

    private fun ok(): RoadPlaneCalibration = (create() as CalibrationResult.Success).calibration
    private fun failure(r: CalibrationResult) = (r as CalibrationResult.Failure).reason

    @Test fun cornersMapToTheEnteredRectangle() {
        val cal = ok()
        val expected = listOf(0.0 to 0.0, 8.0 to 0.0, 8.0 to 30.0, 0.0 to 30.0)
        goodPoints.forEachIndexed { i, p ->
            val w = cal.imageToWorld(p.x, p.y)!!
            assertEquals(expected[i].first, w.x, 1e-6)
            assertEquals(expected[i].second, w.y, 1e-6)
        }
    }

    @Test fun worldToImageIsTheInverse() {
        val cal = ok()
        for ((x, y) in listOf(4.0 to 15.0, 1.0 to 5.0, 7.0 to 25.0, 4.0 to 60.0)) {
            val img = cal.worldToImage(x, y)!!
            val back = cal.imageToWorld(img.x, img.y)!!
            assertEquals(x, back.x, 1e-6)
            assertEquals(y, back.y, 1e-6)
        }
    }

    @Test fun fartherInTheImageMeansLargerRoadDistance() {
        val cal = ok()
        val near = cal.imageToWorld(0.5, 0.85)!!
        val far = cal.imageToWorld(0.5, 0.55)!!
        assertTrue(far.y > near.y)
        assertTrue(near.y > 0.0)
    }

    @Test fun wrongPointCountIsRejected() {
        assertEquals(CalibrationFailure.NEED_FOUR_POINTS, failure(create(goodPoints.take(3))))
    }

    @Test fun implausibleDimensionsAreRejected() {
        assertEquals(CalibrationFailure.INVALID_DIMENSIONS, failure(create(w = 0.0)))
        assertEquals(CalibrationFailure.INVALID_DIMENSIONS, failure(create(l = 0.5)))
        assertEquals(CalibrationFailure.INVALID_DIMENSIONS, failure(create(w = Double.NaN)))
        assertEquals(CalibrationFailure.INVALID_DIMENSIONS, failure(create(l = 1000.0)))
    }

    @Test fun badOrderOrShapeIsRejected() {
        // near edge above the far edge
        assertEquals(CalibrationFailure.BAD_ORDER_OR_GEOMETRY,
            failure(create(listOf(Point2(0.2, 0.5), Point2(0.8, 0.5), Point2(0.65, 0.9), Point2(0.35, 0.9)))))
        // left / right swapped
        assertEquals(CalibrationFailure.BAD_ORDER_OR_GEOMETRY,
            failure(create(listOf(Point2(0.8, 0.9), Point2(0.2, 0.9), Point2(0.35, 0.5), Point2(0.65, 0.5)))))
        // bow-tie (self-intersecting)
        assertEquals(CalibrationFailure.BAD_ORDER_OR_GEOMETRY,
            failure(create(listOf(Point2(0.2, 0.9), Point2(0.8, 0.9), Point2(0.35, 0.5), Point2(0.65, 0.5)))))
        // tiny area: the four taps are almost on top of each other
        assertEquals(CalibrationFailure.BAD_ORDER_OR_GEOMETRY,
            failure(create(listOf(Point2(0.20, 0.9), Point2(0.25, 0.9), Point2(0.24, 0.8), Point2(0.21, 0.8)))))
    }

    // ---- controller ----------------------------------------------------------------------------------------
    private fun controller() = CalibrationController(thresholdRad = 0.026, maxAgeMs = 1000)

    private fun calibrated(c: CalibrationController) {
        c.begin(); goodPoints.forEach { c.addPoint(it) }
        assertTrue(c.complete(8.0, 30.0, 0, 0.0) is CalibrationResult.Success)
    }

    @Test fun controllerHappyPath() {
        val c = controller()
        assertEquals(CalibrationStatus.NOT_CALIBRATED, c.state.value.status)
        assertNull(c.activeCalibration())
        c.begin()
        assertEquals(CalibrationStatus.CALIBRATING, c.state.value.status)
        goodPoints.forEach { c.addPoint(it) }
        c.addPoint(Point2(0.1, 0.1)) // a fifth point is ignored
        assertEquals(4, c.state.value.points.size)
        assertTrue(c.complete(8.0, 30.0, 0, 0.0) is CalibrationResult.Success)
        assertEquals(CalibrationStatus.CALIBRATED, c.state.value.status)
        assertNotNull(c.activeCalibration())
    }

    @Test fun pointsAreIgnoredWhenNotCalibrating() {
        val c = controller()
        c.addPoint(Point2(0.5, 0.5))
        assertTrue(c.state.value.points.isEmpty())
    }

    @Test fun cameraMovedDuringCalibrationIsRejectedAndReset() {
        val c = controller()
        c.begin(); goodPoints.forEach { c.addPoint(it) }
        val r = c.complete(8.0, 30.0, 0, rotationSinceBeginRad = 0.2)
        assertEquals(CalibrationFailure.CAMERA_MOVED_DURING_CALIBRATION, failure(r))
        assertEquals(CalibrationStatus.NOT_CALIBRATED, c.state.value.status)
        assertNull(c.activeCalibration())
    }

    @Test fun missingGyroscopeBlocksCalibration() {
        val c = controller()
        c.begin(); goodPoints.forEach { c.addPoint(it) }
        assertEquals(CalibrationFailure.GYRO_UNAVAILABLE, failure(c.complete(8.0, 30.0, 0, null)))
        assertNull(c.activeCalibration())
    }

    @Test fun failedCompletionKeepsPointsSoTheUserCanFixInput() {
        val c = controller()
        c.begin(); goodPoints.forEach { c.addPoint(it) }
        assertEquals(CalibrationFailure.INVALID_DIMENSIONS, failure(c.complete(0.0, 30.0, 0, 0.0)))
        assertEquals(CalibrationStatus.CALIBRATING, c.state.value.status)
        assertEquals(4, c.state.value.points.size)
        assertTrue(c.complete(8.0, 30.0, 0, 0.0) is CalibrationResult.Success)
    }

    @Test fun cameraMovementInvalidatesCalibration() {
        val c = controller(); calibrated(c)
        c.checkValidity(10, 0.01, true)
        assertEquals(CalibrationStatus.CALIBRATED, c.state.value.status)
        c.checkValidity(20, 0.05, true)
        assertEquals(CalibrationStatus.INVALID, c.state.value.status)
        assertEquals(InvalidReason.CAMERA_MOVED, c.state.value.invalidReason)
        assertNull(c.activeCalibration())
    }

    @Test fun calibrationExpires() {
        val c = controller(); calibrated(c)
        c.checkValidity(2000, 0.0, true)
        assertEquals(InvalidReason.EXPIRED, c.state.value.invalidReason)
        assertNull(c.activeCalibration())
    }

    @Test fun losingTheGyroscopeInvalidatesCalibration() {
        val c = controller(); calibrated(c)
        c.checkValidity(10, null, false)
        assertEquals(InvalidReason.GYRO_LOST, c.state.value.invalidReason)
    }

    @Test fun resetAndUndo() {
        val c = controller()
        c.begin(); c.addPoint(goodPoints[0]); c.addPoint(goodPoints[1]); c.undoPoint()
        assertEquals(1, c.state.value.points.size)
        c.reset()
        assertEquals(CalibrationStatus.NOT_CALIBRATED, c.state.value.status)
    }
}
