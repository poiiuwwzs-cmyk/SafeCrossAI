package com.safecross.ai.risk

import org.junit.Assert.assertEquals
import org.junit.Test

class WarningSmootherTest {
    private fun smoother() = WarningSmoother(dangerHoldMs = 2500, uncertainHoldMs = 2000)

    @Test fun startsUncertain_andClearMustBeEarned() {
        val s = smoother()
        assertEquals(RiskState.UNCERTAIN, s.shown)
        assertEquals(RiskState.UNCERTAIN, s.update(RiskState.POTENTIALLY_CLEAR, 0))
        assertEquals(RiskState.UNCERTAIN, s.update(RiskState.POTENTIALLY_CLEAR, 1900))
        assertEquals(RiskState.POTENTIALLY_CLEAR, s.update(RiskState.POTENTIALLY_CLEAR, 2000))
    }

    @Test fun dangerEscalatesImmediately() {
        val s = smoother()
        s.update(RiskState.POTENTIALLY_CLEAR, 0); s.update(RiskState.POTENTIALLY_CLEAR, 2100)
        assertEquals(RiskState.POTENTIALLY_CLEAR, s.shown)
        assertEquals(RiskState.DANGER, s.update(RiskState.DANGER, 2101))
    }

    @Test fun uncertainEscalatesImmediately() {
        val s = smoother()
        s.update(RiskState.POTENTIALLY_CLEAR, 0); s.update(RiskState.POTENTIALLY_CLEAR, 2100)
        assertEquals(RiskState.UNCERTAIN, s.update(RiskState.UNCERTAIN, 2101))
    }

    @Test fun dangerIsHeldBrieflyAfterRawClears() {
        val s = smoother()
        s.update(RiskState.DANGER, 0)
        assertEquals(RiskState.DANGER, s.update(RiskState.POTENTIALLY_CLEAR, 100))
        assertEquals(RiskState.DANGER, s.update(RiskState.POTENTIALLY_CLEAR, 2500))
        // after the hold, a window that was fully clear drops to clear
        assertEquals(RiskState.POTENTIALLY_CLEAR, s.update(RiskState.POTENTIALLY_CLEAR, 2600))
    }

    @Test fun singleUncertainBlipInsideWindowPreventsClear() {
        val s = smoother()
        s.update(RiskState.DANGER, 0)
        s.update(RiskState.POTENTIALLY_CLEAR, 100)
        s.update(RiskState.UNCERTAIN, 1000)
        s.update(RiskState.POTENTIALLY_CLEAR, 2000)
        assertEquals(RiskState.UNCERTAIN, s.update(RiskState.POTENTIALLY_CLEAR, 2600))
    }

    @Test fun flickerBetweenClearAndUncertainNeverShowsClear() {
        val s = smoother()
        var t = 0L
        repeat(40) { i ->
            val raw = if (i % 2 == 0) RiskState.POTENTIALLY_CLEAR else RiskState.UNCERTAIN
            assertEquals(RiskState.UNCERTAIN, s.update(raw, t))
            t += 250
        }
    }

    @Test fun resetReturnsToUncertain() {
        val s = smoother()
        s.update(RiskState.DANGER, 0)
        s.reset()
        assertEquals(RiskState.UNCERTAIN, s.shown)
    }
}
