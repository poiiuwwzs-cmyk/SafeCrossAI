package com.safecross.ai.detection

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelOutputInterpreterTest {
    private val boxes = arrayOf(
        floatArrayOf(0.2f, 0.1f, 0.6f, 0.5f),   // ymin, xmin, ymax, xmax
        floatArrayOf(0.1f, 0.1f, 0.2f, 0.2f),
        floatArrayOf(0.3f, 0.3f, 0.5f, 0.6f),
        floatArrayOf(0.0f, 0.0f, 0.0f, 0.0f),
    )

    @Test fun decodeMapsBoxesClassesAndFiltersByConfidenceAndClass() {
        val classes = floatArrayOf(2f, 2f, 0f, 7f)   // car, car (low score), person, truck beyond count
        val scores = floatArrayOf(0.9f, 0.3f, 0.95f, 0.8f)
        val out = ModelOutputInterpreter.decode(boxes, classes, scores, count = 3, minConfidence = 0.5f)
        assertEquals(1, out.size)                       // low-score car and person dropped, 4th is beyond count
        assertEquals(VehicleClass.CAR, out[0].vehicleClass)
        assertEquals(0.1f, out[0].box.left, 1e-6f)      // xmin
        assertEquals(0.2f, out[0].box.top, 1e-6f)       // ymin
        assertEquals(0.5f, out[0].box.right, 1e-6f)     // xmax
        assertEquals(0.6f, out[0].box.bottom, 1e-6f)    // ymax
    }

    @Test fun allVehicleClassesAreMapped() {
        val classes = floatArrayOf(1f, 3f, 5f, 7f)
        val scores = floatArrayOf(0.9f, 0.9f, 0.9f, 0.9f)
        val b = Array(4) { floatArrayOf(0.1f, 0.1f, 0.3f, 0.3f) }
        val out = ModelOutputInterpreter.decode(b, classes, scores, 4, 0.5f)
        assertEquals(
            listOf(VehicleClass.BICYCLE, VehicleClass.MOTORCYCLE, VehicleClass.BUS, VehicleClass.TRUCK),
            out.map { it.vehicleClass },
        )
    }

    @Test fun scoresAndClassesCanBeToldApartInEitherOrder() {
        val classes = floatArrayOf(2f, 2f, 0f)
        val scores = floatArrayOf(0.9f, 0.8f, 0f)
        assertEquals(1 to 0, ModelOutputInterpreter.identifyScoresAndClasses(classes, scores))
        assertEquals(0 to 1, ModelOutputInterpreter.identifyScoresAndClasses(scores, classes))
    }

    @Test fun implausibleTensorsAreRejected() {
        assertNull(ModelOutputInterpreter.identifyScoresAndClasses(floatArrayOf(1.5f, 0.5f), floatArrayOf(-3f, 0.2f)))
    }

    @Test fun clampedKeepsBoxesInsideTheFrame() {
        val b = NormBox(-0.1f, -0.2f, 1.2f, 1.1f).clamped()
        assertTrue(b.left == 0f && b.top == 0f && b.right == 1f && b.bottom == 1f)
    }
}
