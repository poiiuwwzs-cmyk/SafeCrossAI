package com.safecross.ai.settings

import com.safecross.ai.risk.ConflictZone
import com.safecross.ai.risk.RiskConfig

enum class AppLanguage(val code: String) { ARABIC("ar"), ENGLISH("en") }

data class AppSettings(
    val language: AppLanguage = AppLanguage.ARABIC,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    /** Detector confidence threshold (configurable for testing). */
    val minConfidence: Float = 0.5f,
    val crossingWidthM: Float = 8f,
    val walkingSpeedMps: Float = 1.0f,
    val safetyMarginS: Float = 3f,
    val zoneLeft: Float = 0.10f,
    val zoneRight: Float = 0.90f,
    val zoneTop: Float = 0.75f,
) {
    /** Clamps every value into a safe, valid range (also protects against a corrupted store). */
    fun sanitized(): AppSettings {
        val left = zoneLeft.coerceIn(0f, 0.45f)
        val right = zoneRight.coerceIn(0.55f, 1f)
        return copy(
            minConfidence = minConfidence.coerceIn(0.2f, 0.9f),
            crossingWidthM = crossingWidthM.coerceIn(2f, 30f),
            walkingSpeedMps = walkingSpeedMps.coerceIn(0.5f, 1.4f), // never faster than a brisk walk
            safetyMarginS = safetyMarginS.coerceIn(2f, 10f),        // never less than 2 s
            zoneLeft = left,
            zoneRight = right,
            zoneTop = zoneTop.coerceIn(0.4f, 0.95f),
        )
    }

    fun toRiskConfig(): RiskConfig = sanitized().let {
        RiskConfig(
            crossingWidthM = it.crossingWidthM.toDouble(),
            walkingSpeedMps = it.walkingSpeedMps.toDouble(),
            safetyMarginS = it.safetyMarginS.toDouble(),
        )
    }

    fun toZone(): ConflictZone = sanitized().let { ConflictZone(it.zoneLeft, it.zoneRight, it.zoneTop) }
}
