package com.safecross.ai.feedback

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.safecross.ai.risk.RiskState

/** Optional sound / vibration. DANGER repeats about every 1.2 s; entering UNCERTAIN gives one short buzz. */
class AlertFeedback(context: Context) {
    private val tone: ToneGenerator? = try {
        ToneGenerator(AudioManager.STREAM_ALARM, 100)
    } catch (e: RuntimeException) {
        null
    }

    private val vibrator: Vibrator? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

    private var lastState = RiskState.UNCERTAIN
    private var lastDangerAlertMs = 0L

    fun onState(state: RiskState, sound: Boolean, vibration: Boolean, nowMs: Long) {
        when (state) {
            RiskState.DANGER -> if (nowMs - lastDangerAlertMs >= 1200) {
                lastDangerAlertMs = nowMs
                if (sound) tone?.startTone(ToneGenerator.TONE_PROP_BEEP2, 250)
                if (vibration) vibrate(longArrayOf(0, 250, 100, 250))
            }
            RiskState.UNCERTAIN -> if (lastState != RiskState.UNCERTAIN && vibration) vibrate(longArrayOf(0, 120))
            RiskState.POTENTIALLY_CLEAR -> Unit
        }
        lastState = state
    }

    private fun vibrate(pattern: LongArray) {
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        v.vibrate(VibrationEffect.createWaveform(pattern, -1))
    }

    fun release() {
        tone?.release()
        vibrator?.cancel()
    }
}
