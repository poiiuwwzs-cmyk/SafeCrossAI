package com.safecross.ai.detection

/**
 * Pure helpers for decoding SSD/EfficientDet-style TFLite outputs. Kept free of Android/TFLite
 * types so they are unit-testable on the JVM.
 *
 * Assumed output convention (TFLite Task / MediaPipe EfficientDet-Lite): boxes are
 * [ymin, xmin, ymax, xmax] normalized to 0..1; classes are zero-based COCO label-map indices.
 * This is UNVERIFIED against the actual file until the on-device check in docs/MODEL.md is done.
 */
object ModelOutputInterpreter {

    /** Zero-based COCO label-map indices (0 = person) for road vehicles. */
    val DEFAULT_CLASS_MAP: Map<Int, VehicleClass> = mapOf(
        1 to VehicleClass.BICYCLE,
        2 to VehicleClass.CAR,
        3 to VehicleClass.MOTORCYCLE,
        5 to VehicleClass.BUS,
        7 to VehicleClass.TRUCK,
    )

    /**
     * Two [1,N] tensors come back (classes, scores) in an order that differs between exports.
     * Scores are in [0,1] and sorted descending after NMS; classes are non-negative integers.
     * Returns (scoresIndex, classesIndex) as 0/1, or null if neither assignment is plausible.
     */
    fun identifyScoresAndClasses(a: FloatArray, b: FloatArray, defaultAIsClasses: Boolean = true): Pair<Int, Int>? {
        val aScores = looksLikeScores(a)
        val bScores = looksLikeScores(b)
        val aClasses = looksLikeClasses(a)
        val bClasses = looksLikeClasses(b)
        return when {
            aScores && bClasses && !(bScores && aClasses) -> 0 to 1
            bScores && aClasses && !(aScores && bClasses) -> 1 to 0
            aScores && bScores && aClasses && bClasses ->
                if (defaultAIsClasses) 1 to 0 else 0 to 1 // ambiguous (e.g. all zeros): use declared order
            else -> null
        }
    }

    private fun looksLikeScores(v: FloatArray): Boolean {
        if (v.any { it.isNaN() || it < 0f || it > 1f }) return false
        for (i in 1 until v.size) if (v[i] > v[i - 1] + 1e-6f) return false
        return true
    }

    private fun looksLikeClasses(v: FloatArray): Boolean =
        v.all { !it.isNaN() && it >= 0f && it == Math.rint(it.toDouble()).toFloat() }

    fun decode(
        boxes: Array<FloatArray>,   // [N][4] = ymin,xmin,ymax,xmax
        classes: FloatArray,
        scores: FloatArray,
        count: Int,
        minConfidence: Float,
        classMap: Map<Int, VehicleClass> = DEFAULT_CLASS_MAP,
    ): List<Detection> {
        val out = ArrayList<Detection>()
        val n = minOf(count, boxes.size, classes.size, scores.size)
        for (i in 0 until n) {
            val score = scores[i]
            if (score < minConfidence) continue
            val vehicleClass = classMap[classes[i].toInt()] ?: continue
            val b = boxes[i]
            val box = NormBox(b[1], b[0], b[3], b[2]).clamped()
            if (box.width <= 0.002f || box.height <= 0.002f) continue
            out += Detection(box, vehicleClass, score)
        }
        return out
    }
}
