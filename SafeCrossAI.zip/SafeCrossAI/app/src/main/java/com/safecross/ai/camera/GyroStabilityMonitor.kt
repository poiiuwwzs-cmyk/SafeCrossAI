package com.safecross.ai.camera

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import kotlin.math.sqrt

/** Source of camera-movement information (handheld shake, accumulated rotation). */
interface CameraStabilitySource {
    /** False if there is no gyroscope or it delivered no data recently: stability then cannot be verified. */
    val isAvailable: Boolean
    /** Smoothed angular speed magnitude, rad/s. */
    val angularRateRadPerS: Double
    /** Rotation accumulated since [markReference], rad. Small drift is suppressed with a dead band. */
    val rotationSinceMarkRad: Double
    fun markReference()
}

/**
 * Gyroscope based monitor (no permission needed). The dead band avoids integrating sensor bias into a false
 * "camera moved" verdict; the flip side is that very slow drifts of the camera are not detected.
 */
class GyroStabilityMonitor(context: Context) : SensorEventListener, CameraStabilitySource {
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val gyro: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

    @Volatile private var rate = 0.0
    @Volatile private var rotation = 0.0
    @Volatile private var lastEventNs = 0L
    @Volatile private var lastArrivalNs = 0L

    override val isAvailable: Boolean
        get() = gyro != null && lastArrivalNs != 0L &&
            SystemClock.elapsedRealtimeNanos() - lastArrivalNs < 1_000_000_000L
    override val angularRateRadPerS: Double get() = rate
    override val rotationSinceMarkRad: Double get() = rotation

    override fun markReference() { rotation = 0.0 }

    fun start() {
        val g = gyro ?: return
        sensorManager.registerListener(this, g, SensorManager.SENSOR_DELAY_GAME)
    }

    fun stop() {
        sensorManager.unregisterListener(this)
        lastArrivalNs = 0L
    }

    override fun onSensorChanged(event: SensorEvent) {
        val w = sqrt((event.values[0] * event.values[0] + event.values[1] * event.values[1] +
            event.values[2] * event.values[2]).toDouble())
        val prev = lastEventNs
        lastEventNs = event.timestamp
        lastArrivalNs = SystemClock.elapsedRealtimeNanos()
        rate = if (prev == 0L) w else 0.7 * rate + 0.3 * w
        if (prev != 0L && w > DEAD_BAND_RAD_PER_S) {
            val dt = (event.timestamp - prev) / 1e9
            if (dt in 0.0..0.5) rotation += w * dt
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    companion object {
        const val DEAD_BAND_RAD_PER_S = 0.01
    }
}
