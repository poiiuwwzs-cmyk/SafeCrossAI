package com.safecross.ai.tracking

import com.safecross.ai.detection.Detection
import com.safecross.ai.detection.NormBox
import com.safecross.ai.detection.VehicleClass
import kotlin.math.exp

data class Observation(val timestampMs: Long, val box: NormBox, val confidence: Float)

/**
 * Apparent (image-space) motion over a recent window. Units: normalized image units per second.
 * This is NOT real-world motion. scaleRate = d ln(box height) / dt (1/s); null if no unclipped boxes allow it.
 */
data class ImageMotion(
    val vx: Double,
    val vy: Double,
    val lateralSigma: Double,
    val scaleRate: Double?,
    val scaleRateSigma: Double?,
    val spanMs: Long,
    val samples: Int,
)

class Track(
    val id: Int,
    first: Detection,
    firstSeenMs: Long,
    private val maxHistory: Int,
) {
    private val observations = ArrayDeque<Observation>()
    private val classVotes = IntArray(VehicleClass.values().size)

    val history: List<Observation> get() = observations
    var hits: Int = 0
        private set
    var lastDetectionMs: Long = firstSeenMs
        private set
    var imageMotion: ImageMotion? = null
        internal set

    val lastObservation: Observation get() = observations.last()
    val lastBox: NormBox get() = observations.last().box
    val lastConfidence: Float get() = observations.last().confidence
    var vehicleClass: VehicleClass = first.vehicleClass
        private set

    init { add(first, firstSeenMs) }

    fun add(d: Detection, timestampMs: Long) {
        observations.addLast(Observation(timestampMs, d.box, d.confidence))
        while (observations.size > maxHistory) observations.removeFirst()
        hits++
        lastDetectionMs = timestampMs
        classVotes[d.vehicleClass.ordinal]++
        var best = 0
        for (i in classVotes.indices) if (classVotes[i] >= classVotes[best]) best = i
        // tie -> most recent vote wins
        vehicleClass = if (classVotes[d.vehicleClass.ordinal] == classVotes[best]) d.vehicleClass
        else VehicleClass.values()[best]
    }

    /** Constant-velocity / constant-scale-rate prediction of the box at [nowMs] (extrapolation capped at 0.5 s). */
    fun predictBox(nowMs: Long): NormBox {
        val m = imageMotion ?: return lastBox
        val dt = ((nowMs - lastDetectionMs) / 1000.0).coerceIn(0.0, 0.5)
        val ds = (m.scaleRate ?: 0.0) * dt
        return lastBox.predicted((m.vx * dt).toFloat(), (m.vy * dt).toFloat(), ds.toFloat())
    }
}
