package com.safecross.ai.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.safecross.ai.permissions.CameraPermissionGate
import com.safecross.ai.settings.AppLanguage

private val HighContrastColors = lightColorScheme(
    primary = Palette.Accent,
    onPrimary = Palette.Paper,
    background = Palette.Paper,
    onBackground = Palette.Ink,
    surface = Palette.Paper,
    onSurface = Palette.Ink,
)

@Composable
fun SafeCrossApp(vm: MainViewModel) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val screen by vm.screen.collectAsStateWithLifecycle()
    val strings = stringsFor(settings.language)
    val direction = if (settings.language == AppLanguage.ARABIC) LayoutDirection.Rtl else LayoutDirection.Ltr

    CompositionLocalProvider(LocalLayoutDirection provides direction) {
        MaterialTheme(colorScheme = HighContrastColors) {
            Surface(Modifier.fillMaxSize(), color = Palette.Paper) {
                when (screen) {
                    Screen.HOME -> HomeScreen(vm, strings)
                    Screen.SETTINGS -> SettingsScreen(vm, strings)
                    Screen.CAMERA, Screen.CALIBRATION -> CameraPermissionGate(
                        title = strings.permTitle,
                        body = strings.permBody,
                        grantLabel = strings.permGrant,
                        openSettingsLabel = strings.permOpenSettings,
                        deniedPermanentlyBody = strings.permDeniedPermanent,
                    ) {
                        if (screen == Screen.CAMERA) CameraScreen(vm, strings) else CalibrationScreen(vm, strings)
                    }
                }
            }
        }
    }
}
