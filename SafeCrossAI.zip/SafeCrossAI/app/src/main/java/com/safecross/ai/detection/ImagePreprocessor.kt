package com.safecross.ai.detection

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Rotates the camera frame upright and stretches it to the model input size (the model is trained on
 * stretched inputs, so normalized output boxes map straight back to the upright frame).
 * All buffers are allocated once and reused. Not thread-safe: use from the analysis thread only.
 */
class ImagePreprocessor(private val width: Int, private val height: Int) {
    private val target = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    private val canvas = Canvas(target)
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val matrix = Matrix()
    private val pixels = IntArray(width * height)
    private val buffer: ByteBuffer = ByteBuffer.allocateDirect(width * height * 3).order(ByteOrder.nativeOrder())

    /** Returns a UINT8 RGB tensor buffer [1,H,W,3] (rewound). The buffer is reused on the next call. */
    fun process(src: Bitmap, rotationDegrees: Int): ByteBuffer {
        val rot = ((rotationDegrees % 360) + 360) % 360
        val rw = if (rot % 180 == 0) src.width else src.height
        val rh = if (rot % 180 == 0) src.height else src.width
        matrix.reset()
        matrix.postTranslate(-src.width / 2f, -src.height / 2f)
        matrix.postRotate(rot.toFloat())
        matrix.postScale(width / rw.toFloat(), height / rh.toFloat())
        matrix.postTranslate(width / 2f, height / 2f)
        canvas.drawBitmap(src, matrix, paint)
        target.getPixels(pixels, 0, width, 0, 0, width, height)
        buffer.rewind()
        for (p in pixels) {
            buffer.put(((p shr 16) and 0xFF).toByte())
            buffer.put(((p shr 8) and 0xFF).toByte())
            buffer.put((p and 0xFF).toByte())
        }
        buffer.rewind()
        return buffer
    }

    fun close() = target.recycle()
}
