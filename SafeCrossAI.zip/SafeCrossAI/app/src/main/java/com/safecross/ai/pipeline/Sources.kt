package com.safecross.ai.pipeline

import android.graphics.Bitmap
import com.safecross.ai.risk.SceneQuality

interface SceneQualityProvider {
    fun analyze(frame: Bitmap): SceneQuality
}

enum class ThermalLevel { NORMAL, ELEVATED, SEVERE }

interface ThermalSource {
    fun level(): ThermalLevel
}
