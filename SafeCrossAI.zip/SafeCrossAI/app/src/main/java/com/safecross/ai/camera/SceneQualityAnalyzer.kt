package com.safecross.ai.camera

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import com.safecross.ai.pipeline.SceneQualityProvider
import com.safecross.ai.risk.PerceptionThresholds
import com.safecross.ai.risk.SceneQuality

/**
 * Cheap scene check on a 96x96 downscale: mean luminance (too dark / too bright) and variance of a Laplacian
 * (blur). These are crude heuristics; a false alarm only makes the app say "wait", never "clear".
 */
class SceneQualityAnalyzer(private val th: PerceptionThresholds) : SceneQualityProvider {
    private val size = 96
    private val small = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    private val canvas = Canvas(small)
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val matrix = Matrix()
    private val pixels = IntArray(size * size)
    private val gray = IntArray(size * size)

    override fun analyze(frame: Bitmap): SceneQuality {
        matrix.setScale(size / frame.width.toFloat(), size / frame.height.toFloat())
        canvas.drawBitmap(frame, matrix, paint)
        small.getPixels(pixels, 0, size, 0, 0, size, size)
        var sum = 0L
        for (i in pixels.indices) {
            val p = pixels[i]
            val g = (299 * ((p shr 16) and 0xFF) + 587 * ((p shr 8) and 0xFF) + 114 * (p and 0xFF)) / 1000
            gray[i] = g
            sum += g
        }
        val mean = sum.toDouble() / pixels.size
        if (mean < th.minMeanLuma) return SceneQuality.TOO_DARK
        if (mean > th.maxMeanLuma) return SceneQuality.TOO_BRIGHT

        var lapSum = 0.0
        var lapSq = 0.0
        var n = 0
        for (y in 1 until size - 1) for (x in 1 until size - 1) {
            val i = y * size + x
            val lap = (4 * gray[i] - gray[i - 1] - gray[i + 1] - gray[i - size] - gray[i + size]).toDouble()
            lapSum += lap; lapSq += lap * lap; n++
        }
        val variance = lapSq / n - (lapSum / n) * (lapSum / n)
        return if (variance < th.minLaplacianVariance) SceneQuality.BLURRY else SceneQuality.OK
    }
}
