package com.safecross.ai.calibration

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class CalibrationStatus { NOT_CALIBRATED, CALIBRATING, CALIBRATED, INVALID }

enum class InvalidReason { CAMERA_MOVED, EXPIRED, GYRO_LOST }

data class CalibrationState(
    val status: CalibrationStatus = CalibrationStatus.NOT_CALIBRATED,
    val points: List<Point2> = emptyList(),
    val calibration: RoadPlaneCalibration? = null,
    val invalidReason: InvalidReason? = null,
    val lastFailure: CalibrationFailure? = null,
)

/**
 * Session-only calibration state machine. Calibration is deliberately never persisted: a calibration is only
 * meaningful for the exact camera pose it was made in. The caller supplies how far the camera has rotated since
 * calibration started (from the gyroscope); any movement beyond the limit invalidates it.
 */
class CalibrationController(private val thresholdRad: Double, private val maxAgeMs: Long) {
    private val _state = MutableStateFlow(CalibrationState())
    val state: StateFlow<CalibrationState> = _state.asStateFlow()

    @Synchronized fun begin() { _state.value = CalibrationState(status = CalibrationStatus.CALIBRATING) }

    @Synchronized fun addPoint(p: Point2) {
        val s = _state.value
        if (s.status != CalibrationStatus.CALIBRATING || s.points.size >= 4) return
        _state.value = s.copy(points = s.points + p, lastFailure = null)
    }

    @Synchronized fun undoPoint() {
        val s = _state.value
        if (s.status == CalibrationStatus.CALIBRATING && s.points.isNotEmpty()) {
            _state.value = s.copy(points = s.points.dropLast(1))
        }
    }

    @Synchronized fun reset() { _state.value = CalibrationState() }

    @Synchronized fun complete(
        widthM: Double, lengthM: Double, nowMs: Long, rotationSinceBeginRad: Double?, 
    ): CalibrationResult {
        val s = _state.value
        if (s.status != CalibrationStatus.CALIBRATING) return fail(s, CalibrationFailure.NEED_FOUR_POINTS)
        if (rotationSinceBeginRad == null) return fail(s, CalibrationFailure.GYRO_UNAVAILABLE)
        if (rotationSinceBeginRad > thresholdRad) {
            _state.value = CalibrationState(lastFailure = CalibrationFailure.CAMERA_MOVED_DURING_CALIBRATION)
            return CalibrationResult.Failure(CalibrationFailure.CAMERA_MOVED_DURING_CALIBRATION)
        }
        return when (val r = RoadPlaneCalibration.create(s.points, widthM, lengthM, nowMs)) {
            is CalibrationResult.Success -> {
                _state.value = CalibrationState(status = CalibrationStatus.CALIBRATED, calibration = r.calibration)
                r
            }
            is CalibrationResult.Failure -> fail(s, r.reason)
        }
    }

    private fun fail(s: CalibrationState, reason: CalibrationFailure): CalibrationResult.Failure {
        _state.value = s.copy(lastFailure = reason)
        return CalibrationResult.Failure(reason)
    }

    /** Called regularly. Invalidates a CALIBRATED state if the camera moved, the gyro vanished, or it expired. */
    @Synchronized fun checkValidity(nowMs: Long, rotationSinceBeginRad: Double?, gyroAvailable: Boolean) {
        val s = _state.value
        if (s.status != CalibrationStatus.CALIBRATED) return
        val cal = s.calibration ?: return
        val reason = when {
            !gyroAvailable || rotationSinceBeginRad == null -> InvalidReason.GYRO_LOST
            rotationSinceBeginRad > thresholdRad -> InvalidReason.CAMERA_MOVED
            nowMs - cal.createdAtMs > maxAgeMs -> InvalidReason.EXPIRED
            else -> null
        } ?: return
        _state.value = CalibrationState(status = CalibrationStatus.INVALID, invalidReason = reason)
    }

    /** The calibration to use for metric estimates, or null unless status is CALIBRATED. */
    fun activeCalibration(): RoadPlaneCalibration? =
        _state.value.takeIf { it.status == CalibrationStatus.CALIBRATED }?.calibration
}
