package com.safecross.ai.calibration

import kotlin.math.abs

data class Point2(val x: Double, val y: Double)
data class WorldPoint(val x: Double, val y: Double)

enum class CalibrationFailure {
    NEED_FOUR_POINTS, INVALID_DIMENSIONS, BAD_ORDER_OR_GEOMETRY, DEGENERATE, CAMERA_MOVED_DURING_CALIBRATION, GYRO_UNAVAILABLE,
}

sealed interface CalibrationResult {
    data class Success(val calibration: RoadPlaneCalibration) : CalibrationResult
    data class Failure(val reason: CalibrationFailure) : CalibrationResult
}

/**
 * Road-plane homography from UPRIGHT normalized image coordinates to metres on the road.
 *
 * The user taps four corners of a rectangle lying on the road, in this order, and enters its real size:
 *   p0 near-left, p1 near-right, p2 far-right, p3 far-left  ->  world (0,0), (W,0), (W,L), (0,L).
 * World X runs across the road, world Y runs along the road AWAY from the camera. The near edge (Y = 0) must be
 * the pedestrian's crossing line; vehicles with decreasing Y are approaching it.
 *
 * Assumptions / limits (also in docs/LIMITATIONS.md): flat road, fixed camera, no lens-distortion correction,
 * tap precision and measured distances directly limit accuracy, far-field error grows rapidly.
 */
class RoadPlaneCalibration private constructor(
    private val h: DoubleArray,
    private val hInv: DoubleArray,
    val widthM: Double,
    val lengthM: Double,
    val createdAtMs: Long,
) {
    fun imageToWorld(nx: Double, ny: Double): WorldPoint? = apply(h, nx, ny)?.let { WorldPoint(it.x, it.y) }

    fun worldToImage(x: Double, y: Double): Point2? = apply(hInv, x, y)

    private fun apply(m: DoubleArray, x: Double, y: Double): Point2? {
        val w = m[6] * x + m[7] * y + m[8]
        if (abs(w) < 1e-9) return null
        val u = (m[0] * x + m[1] * y + m[2]) / w
        val v = (m[3] * x + m[4] * y + m[5]) / w
        return if (u.isFinite() && v.isFinite()) Point2(u, v) else null
    }

    companion object {
        fun create(imagePoints: List<Point2>, widthM: Double, lengthM: Double, nowMs: Long): CalibrationResult {
            if (imagePoints.size != 4) return CalibrationResult.Failure(CalibrationFailure.NEED_FOUR_POINTS)
            if (!(widthM in 0.5..60.0) || !(lengthM in 1.0..300.0)) {
                return CalibrationResult.Failure(CalibrationFailure.INVALID_DIMENSIONS)
            }
            if (!geometryPlausible(imagePoints)) return CalibrationResult.Failure(CalibrationFailure.BAD_ORDER_OR_GEOMETRY)
            val world = listOf(Point2(0.0, 0.0), Point2(widthM, 0.0), Point2(widthM, lengthM), Point2(0.0, lengthM))
            val h = solveHomography(imagePoints, world) ?: return CalibrationResult.Failure(CalibrationFailure.DEGENERATE)
            val inv = invert3x3(h) ?: return CalibrationResult.Failure(CalibrationFailure.DEGENERATE)
            val cal = RoadPlaneCalibration(h, inv, widthM, lengthM, nowMs)
            // Sanity: the four taps must map back onto the entered rectangle.
            for (i in 0 until 4) {
                val p = cal.imageToWorld(imagePoints[i].x, imagePoints[i].y)
                    ?: return CalibrationResult.Failure(CalibrationFailure.DEGENERATE)
                if (abs(p.x - world[i].x) > 1e-3 * widthM || abs(p.y - world[i].y) > 1e-3 * lengthM) {
                    return CalibrationResult.Failure(CalibrationFailure.DEGENERATE)
                }
            }
            return CalibrationResult.Success(cal)
        }

        /** Convex quadrilateral, near edge lower in the image than far edge, left/right consistent, not tiny. */
        internal fun geometryPlausible(p: List<Point2>): Boolean {
            val nearY = (p[0].y + p[1].y) / 2
            val farY = (p[2].y + p[3].y) / 2
            if (nearY - farY < 0.05) return false
            if (p[1].x - p[0].x < 0.02 || p[2].x - p[3].x < 0.01) return false
            var sign = 0
            var area2 = 0.0
            for (i in 0 until 4) {
                val a = p[i]; val b = p[(i + 1) % 4]; val c = p[(i + 2) % 4]
                val cross = (b.x - a.x) * (c.y - b.y) - (b.y - a.y) * (c.x - b.x)
                if (abs(cross) < 1e-9) return false
                val s = if (cross > 0) 1 else -1
                if (sign == 0) sign = s else if (s != sign) return false
                area2 += a.x * b.y - b.x * a.y
            }
            return abs(area2) / 2 >= 0.01
        }

        /** Direct linear transform with h33 = 1; solves the 8x8 system by Gaussian elimination. */
        internal fun solveHomography(src: List<Point2>, dst: List<Point2>): DoubleArray? {
            val a = Array(8) { DoubleArray(9) }
            for (i in 0 until 4) {
                val x = src[i].x; val y = src[i].y; val u = dst[i].x; val v = dst[i].y
                a[2 * i] = doubleArrayOf(x, y, 1.0, 0.0, 0.0, 0.0, -u * x, -u * y, u)
                a[2 * i + 1] = doubleArrayOf(0.0, 0.0, 0.0, x, y, 1.0, -v * x, -v * y, v)
            }
            for (col in 0 until 8) {
                var piv = col
                for (r in col + 1 until 8) if (abs(a[r][col]) > abs(a[piv][col])) piv = r
                if (abs(a[piv][col]) < 1e-12) return null
                val tmp = a[col]; a[col] = a[piv]; a[piv] = tmp
                for (r in 0 until 8) {
                    if (r == col) continue
                    val f = a[r][col] / a[col][col]
                    for (c in col until 9) a[r][c] -= f * a[col][c]
                }
            }
            val h = DoubleArray(9)
            for (i in 0 until 8) h[i] = a[i][8] / a[i][i]
            h[8] = 1.0
            return if (h.all { it.isFinite() }) h else null
        }

        internal fun invert3x3(m: DoubleArray): DoubleArray? {
            val det = m[0] * (m[4] * m[8] - m[5] * m[7]) - m[1] * (m[3] * m[8] - m[5] * m[6]) +
                m[2] * (m[3] * m[7] - m[4] * m[6])
            if (abs(det) < 1e-18) return null
            return doubleArrayOf(
                (m[4] * m[8] - m[5] * m[7]) / det, (m[2] * m[7] - m[1] * m[8]) / det, (m[1] * m[5] - m[2] * m[4]) / det,
                (m[5] * m[6] - m[3] * m[8]) / det, (m[0] * m[8] - m[2] * m[6]) / det, (m[2] * m[3] - m[0] * m[5]) / det,
                (m[3] * m[7] - m[4] * m[6]) / det, (m[1] * m[6] - m[0] * m[7]) / det, (m[0] * m[4] - m[1] * m[3]) / det,
            )
        }
    }
}
