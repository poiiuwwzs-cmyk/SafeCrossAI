package com.safecross.ai.risk

import com.safecross.ai.calibration.MetricMotionEstimator
import com.safecross.ai.calibration.RoadPlaneCalibration
import com.safecross.ai.detection.NormBox
import com.safecross.ai.tracking.Track
import com.safecross.ai.tracking.TrackerParams
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

/**
 * Region of the upright image that represents the pedestrian's conflict area: a vehicle whose box overlaps this
 * rectangle horizontally and whose ground edge (box bottom) is below [top] is considered in or at the zone.
 * Without a calibration this is only an image-space approximation; the user can adjust it in settings.
 */
data class ConflictZone(val left: Float = 0.10f, val right: Float = 0.90f, val top: Float = 0.75f) {
    init { require(left in 0f..1f && right in 0f..1f && left < right && top in 0f..1f) }
    fun overlaps(b: NormBox) = b.right > left && b.left < right && b.bottom > top
}

/** UNVALIDATED heuristic thresholds. Tune with recorded footage (docs/TESTING_PROTOCOL.md). */
data class MotionThresholds(
    /** Minimum significant relative size change, 1/s (0.04 = 4 %/s). */
    val scaleRateMin: Double = 0.04,
    /** Minimum significant lateral image speed, frame-widths per second. */
    val lateralMin: Double = 0.02,
    val sigmaMult: Double = 2.0,
    val lateralDepthMargin: Float = 0.15f,
    /** Safety factor on looming tau: real vehicles may accelerate; tau assumes constant speed, head-on. */
    val tauConservatism: Double = 0.7,
    /** Image-linear extrapolation overestimates time for approaching vehicles (perspective). */
    val lateralConservatism: Double = 0.5,
    val metricSpeedMin: Double = 0.5,
    val metricDistanceFactor: Double = 0.8,
    val metricDistanceOffsetM: Double = 1.0,
    val metricSpeedRelErr: Double = 0.15,
    val zoneDepthM: Double = 5.0,
    val zoneSideMarginM: Double = 2.0,
)

/**
 * Turns tracks into [ThreatInput]s. Two distinct sources, never mixed up:
 *  1. calibrated metric motion (only with a valid [RoadPlaneCalibration]) -> real speed + TTC (TtcBasis.CALIBRATED_METRIC);
 *  2. apparent image motion -> approximate relative TTC (looming tau / lateral gap), flagged as NOT calibrated.
 */
class ThreatAssessor(
    private val th: MotionThresholds = MotionThresholds(),
    private val metricEstimator: MetricMotionEstimator = MetricMotionEstimator(),
) {
    fun assess(
        tracks: List<Track>,
        zone: ConflictZone,
        calibration: RoadPlaneCalibration?,
        nowMs: Long,
        params: TrackerParams,
    ): List<ThreatInput> = tracks.map { assessTrack(it, zone, calibration, nowMs, params) }

    private fun assessTrack(
        track: Track, zone: ConflictZone, cal: RoadPlaneCalibration?, nowMs: Long, params: TrackerParams,
    ): ThreatInput {
        val confirmed = track.hits >= params.minHitsToConfirm
        val lost = nowMs - track.lastDetectionMs > params.lostAfterMs
        if (cal != null && confirmed && !lost) {
            metricEstimator.estimate(track.history, cal)?.let { return metricThreat(track, it, cal) }
        }
        return imageThreat(track, zone, confirmed, lost)
    }

    // ---- calibrated, metric ---------------------------------------------------------------------------------
    private fun metricThreat(track: Track, m: com.safecross.ai.calibration.MetricMotion, cal: RoadPlaneCalibration): ThreatInput {
        val s = th.sigmaMult
        val speedMps = hypot(m.vx, m.vy)
        val speed = SpeedEstimate(speedMps * 3.6, (s * m.sigmaV + th.metricSpeedRelErr * speedMps) * 3.6)
        val approaching = m.vy + s * m.sigmaV < -th.metricSpeedMin
        val receding = m.vy - s * m.sigmaV > th.metricSpeedMin
        val passed = m.y < -1.0 && m.vy < 0
        val still = abs(m.vy) + s * m.sigmaV < th.metricSpeedMin && abs(m.vx) + s * m.sigmaV < th.metricSpeedMin
        val motion = when {
            passed || receding -> MotionClass.RECEDING
            approaching -> MotionClass.APPROACHING
            still -> MotionClass.STATIONARY
            else -> MotionClass.UNKNOWN
        }
        val inZone = m.y <= th.zoneDepthM && m.y >= -3.0 &&
            m.x >= -th.zoneSideMarginM && m.x <= cal.widthM + th.zoneSideMarginM
        var ttc: TimeToConflict? = null
        if (motion == MotionClass.APPROACHING) {
            val closing = -m.vy
            val closingUpper = closing + s * m.sigmaV + th.metricSpeedRelErr * closing
            val distLower = max(0.0, th.metricDistanceFactor * m.y - th.metricDistanceOffsetM)
            val nominal = if (m.y <= 0.0) 0.0 else m.y / closing
            val lower = if (m.y <= 0.0) 0.0 else distLower / closingUpper
            ttc = TimeToConflict.of(nominal, lower, TtcBasis.CALIBRATED_METRIC)
        }
        return ThreatInput(track.id, track.vehicleClass, motion, inZone, false, true, ttc, speed)
    }

    // ---- uncalibrated, image-space ---------------------------------------------------------------------------
    private fun imageThreat(track: Track, zone: ConflictZone, confirmed: Boolean, lost: Boolean): ThreatInput {
        val box = track.lastBox
        val inZone = zone.overlaps(box)
        val m = track.imageMotion
            ?: return ThreatInput(track.id, track.vehicleClass, MotionClass.UNKNOWN, inZone, lost, confirmed, null, null)

        val k = th.sigmaMult
        val sr = m.scaleRate
        val ss = m.scaleRateSigma
        val vSigma = k * m.lateralSigma
        val growing = sr != null && ss != null && sr - k * ss > th.scaleRateMin
        val shrinking = sr != null && ss != null && sr + k * ss < -th.scaleRateMin
        val still = sr != null && ss != null && abs(sr) + k * ss < th.scaleRateMin &&
            hypot(m.vx, m.vy) + vSigma < th.lateralMin
        val side = when {
            box.right <= zone.left -> -1
            box.left >= zone.right -> 1
            else -> 0
        }
        val deep = box.bottom >= zone.top - th.lateralDepthMargin
        val toward = deep && ((side == -1 && m.vx - vSigma > th.lateralMin) || (side == 1 && m.vx + vSigma < -th.lateralMin))
        val away = (side == -1 && m.vx + vSigma < -th.lateralMin) || (side == 1 && m.vx - vSigma > th.lateralMin)
        val crossing = side == 0 && deep && abs(m.vx) - vSigma > th.lateralMin

        val motion = when {
            growing || toward || crossing -> MotionClass.APPROACHING
            shrinking || away -> MotionClass.RECEDING
            still -> MotionClass.STATIONARY
            else -> MotionClass.UNKNOWN
        }

        var ttc: TimeToConflict? = null
        if (motion == MotionClass.APPROACHING) {
            val candidates = ArrayList<TimeToConflict>(2)
            if (growing && sr != null && ss != null) {
                // Looming: tau = h / (dh/dt) = 1 / scaleRate; use the upper plausible growth rate for the bound.
                candidates += TimeToConflict.of(1.0 / sr, th.tauConservatism / (sr + k * ss), TtcBasis.IMAGE_SCALE_TAU)
            }
            if (toward) {
                val gap = if (side == -1) zone.left - box.right else box.left - zone.right
                val v = abs(m.vx)
                candidates += TimeToConflict.of(gap / v, th.lateralConservatism * gap / (v + vSigma), TtcBasis.IMAGE_LATERAL)
            }
            if (crossing) candidates += TimeToConflict.of(0.0, 0.0, TtcBasis.IMAGE_LATERAL)
            ttc = candidates.minByOrNull { it.lowerBoundS }
        }
        return ThreatInput(track.id, track.vehicleClass, motion, inZone, lost, confirmed, ttc, null)
    }
}
