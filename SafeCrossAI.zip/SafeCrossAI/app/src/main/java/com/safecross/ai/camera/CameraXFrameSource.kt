package com.safecross.ai.camera

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import android.util.Size
import androidx.camera.core.AspectRatio
import androidx.camera.core.CameraSelector
import androidx.camera.core.CameraState
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.UseCaseGroup
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.Observer
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

enum class CameraProblem { NO_BACK_CAMERA, CAMERA_ERROR, CAMERA_CLOSED }

/** Camera capture layer: CameraX Preview + ImageAnalysis (RGBA, latest-frame-only, rate limited). */
class CameraXFrameSource(
    private val context: Context,
    private val minIntervalMs: () -> Long,
) {
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private var provider: ProcessCameraProvider? = null
    private var stateObserver: Observer<CameraState>? = null
    private var observedInfo: androidx.camera.core.CameraInfo? = null
    @Volatile private var generation = 0
    @Volatile private var lastAcceptedMs = 0L

    /** [onFrame] runs on the analysis thread; the bitmap is recycled right after it returns. */
    fun start(
        owner: LifecycleOwner,
        previewView: PreviewView,
        onFrame: (bitmap: Bitmap, rotationDegrees: Int, timestampMs: Long) -> Unit,
        onFrameError: (Throwable) -> Unit,
        /** problem == null means the camera is open and healthy. */
        onProblem: (CameraProblem?, String?) -> Unit,
    ) {
        val myGeneration = ++generation
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            if (myGeneration != generation) return@addListener
            try {
                val p = future.get()
                provider = p
                if (!p.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA)) {
                    onProblem(CameraProblem.NO_BACK_CAMERA, null)
                    return@addListener
                }
                val aspect = AspectRatioStrategy(AspectRatio.RATIO_4_3, AspectRatioStrategy.FALLBACK_RULE_AUTO)
                val preview = Preview.Builder()
                    .setResolutionSelector(ResolutionSelector.Builder().setAspectRatioStrategy(aspect).build())
                    .build()
                    .also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val analysis = ImageAnalysis.Builder()
                    .setResolutionSelector(
                        ResolutionSelector.Builder()
                            .setAspectRatioStrategy(aspect)
                            .setResolutionStrategy(
                                ResolutionStrategy(Size(640, 480), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER),
                            ).build(),
                    )
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(executor) { image -> analyze(image, onFrame, onFrameError) }

                val group = UseCaseGroup.Builder().addUseCase(preview).addUseCase(analysis)
                    .apply { previewView.viewPort?.let { setViewPort(it) } }
                    .build()
                p.unbindAll()
                val camera = p.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, group)
                var sawOpen = false
                val observer = Observer<CameraState> { state ->
                    val err = state.error
                    when {
                        err != null -> onProblem(CameraProblem.CAMERA_ERROR, "code=${err.code}")
                        state.type == CameraState.Type.OPEN -> { sawOpen = true; onProblem(null, null) }
                        state.type == CameraState.Type.CLOSED && sawOpen -> onProblem(CameraProblem.CAMERA_CLOSED, null)
                        else -> Unit
                    }
                }
                stateObserver = observer
                observedInfo = camera.cameraInfo
                camera.cameraInfo.cameraState.observe(owner, observer)
            } catch (t: Throwable) {
                onProblem(CameraProblem.CAMERA_ERROR, t.javaClass.simpleName + ": " + t.message)
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun analyze(
        image: ImageProxy,
        onFrame: (Bitmap, Int, Long) -> Unit,
        onFrameError: (Throwable) -> Unit,
    ) {
        var bitmap: Bitmap? = null
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - lastAcceptedMs < minIntervalMs()) return
            lastAcceptedMs = now
            bitmap = image.toBitmap()
            onFrame(bitmap, image.imageInfo.rotationDegrees, now)
        } catch (t: Throwable) {
            onFrameError(t)
        } finally {
            bitmap?.recycle()
            image.close() // every frame MUST be closed or the camera stalls
        }
    }

    /** Must be called on the main thread. */
    fun stop() {
        generation++
        stateObserver?.let { obs -> observedInfo?.cameraState?.removeObserver(obs) }
        stateObserver = null
        observedInfo = null
        provider?.unbindAll()
    }

    fun release() {
        stop()
        executor.shutdown()
    }
}
