package com.safecross.ai.detection

/**
 * Describes the tensor layout and class ids of a detection model.
 *
 * Default profile: EfficientDet-Lite0 "detection" (uint8 input 320x320x3, COCO-trained), as used in the
 * TensorFlow Lite object-detection examples. Output order there is: boxes [1,N,4] (ymin,xmin,ymax,xmax,
 * normalized), classes [1,N], scores [1,N], count [1].
 *
 * Class ids: 0-based COCO label map where 0 = person. The ids used here (1 bicycle, 2 car, 3 motorcycle,
 * 5 bus, 7 truck) are identical in both the 80-class and the 90-class (with "???" gaps) variants because the
 * gaps only start after id 10. VERIFY these on-device with real footage (see docs/MODEL.md): the detector
 * additionally refuses implausible outputs instead of guessing.
 */
data class ModelProfile(
    val boxesIndex: Int,
    val classesIndex: Int,
    val scoresIndex: Int,
    val countIndex: Int,
    val vehicleClassIds: Map<Int, VehicleClass>,
) {
    companion object {
        val EFFICIENTDET_LITE0 = ModelProfile(
            boxesIndex = 0, classesIndex = 1, scoresIndex = 2, countIndex = 3,
            vehicleClassIds = ModelOutputInterpreter.DEFAULT_CLASS_MAP,
        )
    }
}
