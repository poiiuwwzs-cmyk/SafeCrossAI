package com.safecross.ai.detection

import android.graphics.Bitmap
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

enum class VehicleClass { CAR, BUS, TRUCK, MOTORCYCLE, BICYCLE }

/** Axis-aligned box in UPRIGHT normalized image coordinates: x to the right, y downwards, both in [0,1]. */
data class NormBox(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top
    val centerX: Float get() = (left + right) / 2f
    val centerY: Float get() = (top + bottom) / 2f
    val area: Float get() = max(0f, width) * max(0f, height)

    fun clamped() = NormBox(left.coerceIn(0f, 1f), top.coerceIn(0f, 1f), right.coerceIn(0f, 1f), bottom.coerceIn(0f, 1f))

    /** True when the box is cut by the frame border, so its size/ground point is not trustworthy. */
    fun touchesBorder(eps: Float = 0.005f): Boolean =
        left <= eps || top <= eps || right >= 1f - eps || bottom >= 1f - eps

    fun iou(other: NormBox): Float {
        val iw = min(right, other.right) - max(left, other.left)
        val ih = min(bottom, other.bottom) - max(top, other.top)
        if (iw <= 0f || ih <= 0f) return 0f
        val inter = iw * ih
        val union = area + other.area - inter
        return if (union <= 0f) 0f else inter / union
    }

    /** Moves the box by (dx, dy) and scales it about its centre by exp(logScale). */
    fun predicted(dx: Float, dy: Float, logScale: Float): NormBox {
        val f = exp(logScale)
        val cx = centerX + dx
        val cy = centerY + dy
        val hw = width * f / 2f
        val hh = height * f / 2f
        return NormBox(cx - hw, cy - hh, cx + hw, cy + hh)
    }
}

data class Detection(val box: NormBox, val vehicleClass: VehicleClass, val confidence: Float)

/** Input for a detector. [bitmap] is the raw (sensor-orientation) frame; [rotationDegrees] is clockwise rotation to upright. */
class DetectorInput(val bitmap: Bitmap, val rotationDegrees: Int, val timestampMs: Long)

class ModelUnavailableException(message: String) : Exception(message)
class DetectorOutputException(message: String) : Exception(message)

interface VehicleDetector {
    val isReady: Boolean

    /** Technical (English) reason why the detector cannot run, or null when ready. */
    val unavailableReason: String?

    /** Returns detections in upright normalized coordinates. Throws if not ready or if output is implausible. */
    fun detect(input: DetectorInput): List<Detection>

    fun close()
}
