package com.safecross.ai.ui

import android.app.Application
import android.os.SystemClock
import androidx.camera.view.PreviewView
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.viewModelScope
import com.safecross.ai.calibration.CalibrationController
import com.safecross.ai.calibration.CalibrationFailure
import com.safecross.ai.calibration.CalibrationResult
import com.safecross.ai.calibration.Point2
import com.safecross.ai.camera.AndroidThermalSource
import com.safecross.ai.camera.CameraProblem
import com.safecross.ai.camera.CameraXFrameSource
import com.safecross.ai.camera.GyroStabilityMonitor
import com.safecross.ai.camera.SceneQualityAnalyzer
import com.safecross.ai.detection.DetectorInput
import com.safecross.ai.detection.TfliteVehicleDetector
import com.safecross.ai.feedback.AlertFeedback
import com.safecross.ai.pipeline.AnalysisPipeline
import com.safecross.ai.pipeline.AnalysisUiState
import com.safecross.ai.risk.PerceptionThresholds
import com.safecross.ai.risk.RiskEngine
import com.safecross.ai.risk.ThreatAssessor
import com.safecross.ai.risk.WarningSmoother
import com.safecross.ai.settings.AppSettings
import com.safecross.ai.settings.SettingsRepository
import com.safecross.ai.tracking.VehicleTracker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class Screen { HOME, CAMERA, CALIBRATION, SETTINGS }

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val thresholds = PerceptionThresholds()
    private val repo = SettingsRepository(app)
    private val clock: () -> Long = { SystemClock.elapsedRealtime() }

    val settings: StateFlow<AppSettings> =
        repo.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    private val _screen = MutableStateFlow(Screen.HOME)
    val screen: StateFlow<Screen> = _screen.asStateFlow()

    private val _ui = MutableStateFlow(AnalysisUiState())
    val ui: StateFlow<AnalysisUiState> = _ui.asStateFlow()

    private val _cameraProblem = MutableStateFlow<CameraProblem?>(null)
    val cameraProblem: StateFlow<CameraProblem?> = _cameraProblem.asStateFlow()

    val stability = GyroStabilityMonitor(app)
    val calibration = CalibrationController(thresholds.calibrationMaxRotationRad, thresholds.calibrationMaxAgeMs)

    /** Cheap check so the home screen can warn before the user even starts. */
    val modelFilePresent: Boolean =
        app.assets.list("")?.contains(TfliteVehicleDetector.DEFAULT_MODEL_ASSET) == true

    private var pipeline: AnalysisPipeline? = null
    private var detector: TfliteVehicleDetector? = null
    private var watchdog: Job? = null
    private val camera = CameraXFrameSource(app) { pipeline?.suggestedFrameIntervalMs() ?: thresholds.baseFrameIntervalMs }
    private val feedback = AlertFeedback(app)

    init {
        viewModelScope.launch { settings.collect { applySettings(it) } }
    }

    // ---- navigation ---------------------------------------------------------------------------------------
    fun startMonitoring() { _screen.value = Screen.CAMERA }
    fun openSettings() { _screen.value = Screen.SETTINGS }
    fun goHome() { stopSession(); _screen.value = Screen.HOME }
    fun openCalibration() { _screen.value = Screen.CALIBRATION; beginCalibration() }
    fun leaveCalibration() { calibration.reset(); _screen.value = Screen.CAMERA }

    /** Called when the app leaves the foreground: never keep analysing (or keep a calibration) in the background. */
    fun onAppBackgrounded() {
        if (_screen.value == Screen.CAMERA || _screen.value == Screen.CALIBRATION) goHome()
    }

    // ---- session ------------------------------------------------------------------------------------------
    private fun ensureSession() {
        if (pipeline != null) return
        val s = settings.value
        val det = TfliteVehicleDetector(getApplication(), minConfidence = s.minConfidence)
        detector = det
        val p = AnalysisPipeline(
            detector = det,
            tracker = VehicleTracker(),
            assessor = ThreatAssessor(),
            engine = RiskEngine(),
            smoother = WarningSmoother(),
            calibration = calibration,
            stability = stability,
            thermal = AndroidThermalSource(getApplication()),
            scene = SceneQualityAnalyzer(thresholds),
            thresholds = thresholds,
            clock = clock,
            onUpdate = { _ui.value = it },
        )
        p.riskConfig = s.toRiskConfig()
        p.zone = s.toZone()
        pipeline = p
        stability.start()
        watchdog = viewModelScope.launch(Dispatchers.Default) {
            while (isActive) {
                delay(250)
                p.reevaluate()
                val cur = settings.value
                feedback.onState(_ui.value.risk, cur.soundEnabled, cur.vibrationEnabled, clock())
            }
        }
    }

    private fun stopSession() {
        camera.stop()
        watchdog?.cancel(); watchdog = null
        stability.stop()
        pipeline?.close()
        pipeline = null
        detector = null
        calibration.reset() // a calibration only holds for the exact camera pose and session it was made in
        _ui.value = AnalysisUiState()
        _cameraProblem.value = null
    }

    /** Main thread. Starts the session if needed and binds the camera to [owner]. */
    fun startCamera(owner: LifecycleOwner, previewView: PreviewView) {
        ensureSession()
        camera.start(
            owner, previewView,
            onFrame = { bitmap, rotation, ts -> pipeline?.processFrame(DetectorInput(bitmap, rotation, ts)) },
            onFrameError = { pipeline?.reportFrameError(it) },
            onProblem = { problem, _ -> _cameraProblem.value = problem },
        )
    }

    fun stopCamera() = camera.stop()

    private fun applySettings(s: AppSettings) {
        pipeline?.riskConfig = s.toRiskConfig()
        pipeline?.zone = s.toZone()
        detector?.minConfidence = s.minConfidence
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { repo.update(transform) }
    }

    // ---- calibration ----------------------------------------------------------------------------------------
    fun beginCalibration() {
        stability.markReference()
        calibration.begin()
    }

    fun addCalibrationPoint(nx: Float, ny: Float) = calibration.addPoint(Point2(nx.toDouble(), ny.toDouble()))
    fun undoCalibrationPoint() = calibration.undoPoint()

    fun confirmCalibration(widthM: Double, lengthM: Double): CalibrationFailure? {
        val rotation = if (stability.isAvailable) stability.rotationSinceMarkRad else null
        return when (val r = calibration.complete(widthM, lengthM, clock(), rotation)) {
            is CalibrationResult.Success -> { _screen.value = Screen.CAMERA; null }
            is CalibrationResult.Failure -> r.reason
        }
    }

    override fun onCleared() {
        stopSession()
        camera.release()
        feedback.release()
        super.onCleared()
    }
}
