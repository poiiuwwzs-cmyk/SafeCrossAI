package com.safecross.ai.settings

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.settingsStore by preferencesDataStore(name = "safecross_settings")

/** Local-only settings. Never contains images, locations or identifiers. */
class SettingsRepository(private val context: Context) {

    val settings: Flow<AppSettings> = context.settingsStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { it.toSettings() }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.settingsStore.edit { prefs ->
            val updated = transform(prefs.toSettings()).sanitized()
            prefs[LANGUAGE] = updated.language.code
            prefs[SOUND] = updated.soundEnabled
            prefs[VIBRATION] = updated.vibrationEnabled
            prefs[MIN_CONF] = updated.minConfidence
            prefs[WIDTH] = updated.crossingWidthM
            prefs[WALK] = updated.walkingSpeedMps
            prefs[MARGIN] = updated.safetyMarginS
            prefs[ZONE_L] = updated.zoneLeft
            prefs[ZONE_R] = updated.zoneRight
            prefs[ZONE_T] = updated.zoneTop
        }
    }

    private fun Preferences.toSettings(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            language = AppLanguage.values().firstOrNull { it.code == this[LANGUAGE] } ?: d.language,
            soundEnabled = this[SOUND] ?: d.soundEnabled,
            vibrationEnabled = this[VIBRATION] ?: d.vibrationEnabled,
            minConfidence = this[MIN_CONF] ?: d.minConfidence,
            crossingWidthM = this[WIDTH] ?: d.crossingWidthM,
            walkingSpeedMps = this[WALK] ?: d.walkingSpeedMps,
            safetyMarginS = this[MARGIN] ?: d.safetyMarginS,
            zoneLeft = this[ZONE_L] ?: d.zoneLeft,
            zoneRight = this[ZONE_R] ?: d.zoneRight,
            zoneTop = this[ZONE_T] ?: d.zoneTop,
        ).sanitized()
    }

    private companion object {
        val LANGUAGE = stringPreferencesKey("language")
        val SOUND = booleanPreferencesKey("sound")
        val VIBRATION = booleanPreferencesKey("vibration")
        val MIN_CONF = floatPreferencesKey("min_confidence")
        val WIDTH = floatPreferencesKey("crossing_width_m")
        val WALK = floatPreferencesKey("walking_speed_mps")
        val MARGIN = floatPreferencesKey("safety_margin_s")
        val ZONE_L = floatPreferencesKey("zone_left")
        val ZONE_R = floatPreferencesKey("zone_right")
        val ZONE_T = floatPreferencesKey("zone_top")
    }
}
