package com.safecross.ai.pipeline

import android.util.Log
import com.safecross.ai.calibration.CalibrationController
import com.safecross.ai.camera.CameraStabilitySource
import com.safecross.ai.detection.DetectorInput
import com.safecross.ai.detection.VehicleDetector
import com.safecross.ai.risk.ConflictZone
import com.safecross.ai.risk.HealthIssue
import com.safecross.ai.risk.PerceptionHealth
import com.safecross.ai.risk.PerceptionThresholds
import com.safecross.ai.risk.RiskConfig
import com.safecross.ai.risk.RiskEngine
import com.safecross.ai.risk.RiskInput
import com.safecross.ai.risk.SceneQuality
import com.safecross.ai.risk.ThreatAssessor
import com.safecross.ai.risk.WarningSmoother
import com.safecross.ai.tracking.VehicleTracker

/**
 * Orchestrates detection -> tracking -> threat assessment -> risk -> smoothing.
 * [processFrame] runs on the camera analysis thread; [reevaluate] runs on a watchdog tick so that a frozen
 * camera or a stalled analyzer degrades to WAIT/UNCERTAIN instead of keeping an old "potentially clear".
 */
class AnalysisPipeline(
    private val detector: VehicleDetector,
    private val tracker: VehicleTracker,
    private val assessor: ThreatAssessor,
    private val engine: RiskEngine,
    private val smoother: WarningSmoother,
    private val calibration: CalibrationController,
    private val stability: CameraStabilitySource,
    private val thermal: ThermalSource,
    private val scene: SceneQualityProvider,
    private val thresholds: PerceptionThresholds,
    private val clock: () -> Long,
    private val onUpdate: (AnalysisUiState) -> Unit,
) {
    @Volatile var riskConfig: RiskConfig = RiskConfig()
    @Volatile var zone: ConflictZone = ConflictZone()

    private var lastFrameCaptureMs = -1L
    private var latencyEmaMs = 0.0
    private var intervalEmaMs = 0.0
    private var lastProcessedClock = -1L
    private var sceneQuality = SceneQuality.OK
    private var trackingFailed = false

    val detectorReady: Boolean get() = detector.isReady

    fun suggestedFrameIntervalMs(): Long = when (thermal.level()) {
        ThermalLevel.NORMAL -> thresholds.baseFrameIntervalMs
        ThermalLevel.ELEVATED -> thresholds.baseFrameIntervalMs * 2
        ThermalLevel.SEVERE -> thresholds.baseFrameIntervalMs * 3
    }

    @Synchronized
    fun processFrame(input: DetectorInput) {
        val started = clock()
        try {
            sceneQuality = scene.analyze(input.bitmap)
            val detections = detector.detect(input)
            tracker.update(detections, input.timestampMs)
            lastFrameCaptureMs = input.timestampMs
            trackingFailed = false
            val done = clock()
            val duration = (done - started).toDouble()
            latencyEmaMs = if (latencyEmaMs == 0.0) duration else 0.7 * latencyEmaMs + 0.3 * duration
            if (lastProcessedClock > 0) {
                val dt = (done - lastProcessedClock).toDouble()
                intervalEmaMs = if (intervalEmaMs == 0.0) dt else 0.8 * intervalEmaMs + 0.2 * dt
            }
            lastProcessedClock = done
        } catch (t: Throwable) {
            trackingFailed = true
            Log.w(TAG, "frame analysis failed", t)
        }
        publish()
    }

    /** A camera/analysis exception that happened before the pipeline got the frame. */
    @Synchronized
    fun reportFrameError(t: Throwable) {
        trackingFailed = true
        Log.w(TAG, "camera frame error", t)
        publish()
    }

    @Synchronized fun reevaluate() = publish()

    @Synchronized
    fun reset() {
        tracker.reset()
        smoother.reset()
        lastFrameCaptureMs = -1L
        trackingFailed = false
        latencyEmaMs = 0.0
        intervalEmaMs = 0.0
        lastProcessedClock = -1L
    }

    private fun publish() {
        val now = clock()
        val gyroOk = stability.isAvailable
        calibration.checkValidity(now, if (gyroOk) stability.rotationSinceMarkRad else null, gyroOk)
        val calState = calibration.state.value
        val config = riskConfig
        val currentZone = zone

        val threats = assessor.assess(tracker.activeTracks, currentZone, calibration.activeCalibration(), now, tracker.params)
        val health = PerceptionHealth(
            modelReady = detector.isReady,
            lastFrameAgeMs = if (lastFrameCaptureMs < 0) PerceptionHealth.NO_FRAME_YET_MS else now - lastFrameCaptureMs,
            inferenceLatencyMs = latencyEmaMs.toLong(),
            cameraStable = gyroOk && stability.angularRateRadPerS <= thresholds.maxShakeRateRadPerS,
            sceneQuality = sceneQuality,
            thermalSevere = thermal.level() == ThermalLevel.SEVERE,
            trackingFailed = trackingFailed,
        )
        val assessment = engine.evaluate(RiskInput(threats, health), config)
        val shown = smoother.update(assessment.state, now)

        val tracks = tracker.activeTracks.mapIndexed { i, t ->
            TrackUi(
                id = t.id, vehicleClass = t.vehicleClass, box = t.lastBox, confidence = t.lastConfidence,
                motion = threats[i].motion, isLost = threats[i].isLost, confirmed = threats[i].trackConfirmed,
                speed = threats[i].speed,
            )
        }
        val issues = assessment.issues
        val status = when {
            lastFrameCaptureMs < 0 && HealthIssue.MODEL_UNAVAILABLE !in issues -> AnalysisStatus.STARTING
            HealthIssue.ANALYSIS_SLOW in issues -> AnalysisStatus.SLOW
            HealthIssue.CAMERA_UNSTABLE in issues -> AnalysisStatus.UNSTABLE_CAMERA
            issues.isNotEmpty() -> AnalysisStatus.UNRELIABLE
            else -> AnalysisStatus.ANALYZING
        }
        onUpdate(
            AnalysisUiState(
                risk = shown,
                assessment = assessment,
                tracks = tracks,
                calibration = calState.status,
                analysisStatus = status,
                dominantTtc = assessment.dominant?.threat?.ttc,
                dominantSpeed = assessment.dominant?.threat?.speed,
                issues = issues,
                modelUnavailableReason = detector.unavailableReason,
                latencyMs = latencyEmaMs.toLong(),
                fps = if (intervalEmaMs > 0) (1000.0 / intervalEmaMs).toFloat() else 0f,
                zone = currentZone,
            ),
        )
    }

    fun close() = detector.close()

    private companion object {
        const val TAG = "SafeCross"
    }
}
