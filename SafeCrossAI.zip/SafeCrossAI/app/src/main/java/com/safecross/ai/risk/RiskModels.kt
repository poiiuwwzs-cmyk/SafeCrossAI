package com.safecross.ai.risk

import com.safecross.ai.detection.VehicleClass

/** Overall warning state. There is deliberately no "SAFE" state. */
enum class RiskState(val severity: Int) { POTENTIALLY_CLEAR(0), UNCERTAIN(1), DANGER(2) }

enum class MotionClass { APPROACHING, RECEDING, STATIONARY, UNKNOWN }

/** How a time-to-conflict was obtained. Only CALIBRATED_METRIC can ever support a "potentially clear" verdict. */
enum class TtcBasis { CALIBRATED_METRIC, IMAGE_SCALE_TAU, IMAGE_LATERAL }

enum class SceneQuality { OK, TOO_DARK, TOO_BRIGHT, BLURRY }

enum class HealthIssue {
    MODEL_UNAVAILABLE, NO_RECENT_FRAME, ANALYSIS_SLOW, CAMERA_UNSTABLE,
    TOO_DARK, TOO_BRIGHT, BLURRY, THERMAL_THROTTLING, TRACKING_FAILURE,
}

enum class RiskReason {
    BELOW_SAFETY_MARGIN,
    APPROACHING_IN_ZONE_UNKNOWN_TTC,
    APPROACHING_UNKNOWN_TTC,
    LOST_APPROACHING_TRACK,
    STATIONARY_IN_ZONE,
    UNKNOWN_MOTION,
    UNCONFIRMED_TRACK_IN_ZONE,
    TTC_UNCALIBRATED,
    LOST_TRACK_IN_ZONE,
    TTC_ABOVE_MARGIN_CALIBRATED,
}

data class SpeedEstimate(val kmh: Double, val uncertaintyKmh: Double)

/**
 * Time until the vehicle reaches the conflict zone. [lowerBoundS] is the CONSERVATIVE value (never larger
 * than [nominalS]) and is the only one used for safety decisions.
 */
data class TimeToConflict(val nominalS: Double, val lowerBoundS: Double, val basis: TtcBasis) {
    companion object {
        fun of(nominalS: Double, lowerBoundS: Double, basis: TtcBasis): TimeToConflict {
            val nominal = nominalS.coerceAtLeast(0.0)
            val lower = lowerBoundS.coerceIn(0.0, nominal)
            return TimeToConflict(nominal, lower, basis)
        }
    }
}

/** One tracked vehicle as seen by the risk engine. */
data class ThreatInput(
    val trackId: Int,
    val vehicleClass: VehicleClass,
    val motion: MotionClass,
    val inOrOverlapsZone: Boolean,
    val isLost: Boolean,
    val trackConfirmed: Boolean,
    val ttc: TimeToConflict?,
    val speed: SpeedEstimate?,
)

data class PerceptionHealth(
    val modelReady: Boolean,
    /** Age of the newest analysed frame; use [NO_FRAME_YET_MS] if none was analysed yet. */
    val lastFrameAgeMs: Long,
    val inferenceLatencyMs: Long,
    val cameraStable: Boolean,
    val sceneQuality: SceneQuality,
    val thermalSevere: Boolean,
    val trackingFailed: Boolean,
) {
    companion object {
        const val NO_FRAME_YET_MS = Long.MAX_VALUE / 4
    }
}

data class RiskInput(val threats: List<ThreatInput>, val health: PerceptionHealth)

data class ThreatEvaluation(
    val threat: ThreatInput,
    val state: RiskState,
    val reason: RiskReason,
    /** lowerBound - required crossing time, in seconds (negative = inadequate margin). */
    val marginS: Double?,
)

data class RiskAssessment(
    val state: RiskState,
    val issues: List<HealthIssue>,
    val evaluations: List<ThreatEvaluation>,
    val dominant: ThreatEvaluation?,
    val requiredClearTimeS: Double,
) {
    val calibrationMissingForDecision: Boolean
        get() = evaluations.any { it.reason == RiskReason.TTC_UNCALIBRATED }
}
