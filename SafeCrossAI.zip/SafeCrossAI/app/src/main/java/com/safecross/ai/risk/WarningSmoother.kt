package com.safecross.ai.risk

/**
 * Anti-flicker filter. Escalation is IMMEDIATE (an instant DANGER is never delayed). De-escalation only
 * happens after the raw state stayed lower for a hold time, and then drops only to the WORST raw state seen
 * during that window, so a single clear frame between two uncertain ones cannot show "potentially clear".
 * Starts in UNCERTAIN: "potentially clear" must be earned.
 */
class WarningSmoother(
    private val dangerHoldMs: Long = 2500,
    private val uncertainHoldMs: Long = 2000,
) {
    var shown: RiskState = RiskState.UNCERTAIN
        private set
    private var lowerSinceMs: Long? = null
    private var windowWorst: RiskState = RiskState.POTENTIALLY_CLEAR

    fun update(raw: RiskState, nowMs: Long): RiskState {
        if (raw.severity >= shown.severity) {
            shown = raw
            lowerSinceMs = null
            windowWorst = RiskState.POTENTIALLY_CLEAR
            return shown
        }
        val since = lowerSinceMs
        if (since == null) {
            lowerSinceMs = nowMs
            windowWorst = raw
        } else if (raw.severity > windowWorst.severity) {
            windowWorst = raw
        }
        val hold = if (shown == RiskState.DANGER) dangerHoldMs else uncertainHoldMs
        val start = lowerSinceMs ?: nowMs
        if (nowMs - start >= hold) {
            shown = windowWorst
            lowerSinceMs = null
            windowWorst = RiskState.POTENTIALLY_CLEAR
        }
        return shown
    }

    fun reset() {
        shown = RiskState.UNCERTAIN
        lowerSinceMs = null
        windowWorst = RiskState.POTENTIALLY_CLEAR
    }
}
