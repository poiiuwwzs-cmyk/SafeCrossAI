package com.safecross.ai.camera

import android.content.Context
import android.os.Build
import android.os.PowerManager
import com.safecross.ai.pipeline.ThermalLevel
import com.safecross.ai.pipeline.ThermalSource

class AndroidThermalSource(context: Context) : ThermalSource {
    private val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager

    override fun level(): ThermalLevel {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return ThermalLevel.NORMAL
        val s = pm.currentThermalStatus
        return when {
            s >= PowerManager.THERMAL_STATUS_SEVERE -> ThermalLevel.SEVERE
            s >= PowerManager.THERMAL_STATUS_MODERATE -> ThermalLevel.ELEVATED
            else -> ThermalLevel.NORMAL
        }
    }
}
