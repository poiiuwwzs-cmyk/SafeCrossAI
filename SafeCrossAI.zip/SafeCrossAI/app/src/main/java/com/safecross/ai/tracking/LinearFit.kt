package com.safecross.ai.tracking

import kotlin.math.sqrt

data class LinearFitResult(val slope: Double, val intercept: Double, val slopeSigma: Double)

object LinearFit {
    /**
     * Ordinary least squares y = intercept + slope * t using the first [n] samples.
     * slopeSigma is the standard error of the slope (residual variance / sum of squared time deviations).
     * Returns null for n < 4 or a degenerate time axis.
     */
    fun fit(t: DoubleArray, y: DoubleArray, n: Int = minOf(t.size, y.size)): LinearFitResult? {
        if (n < 4) return null
        var tm = 0.0
        var ym = 0.0
        for (i in 0 until n) { tm += t[i]; ym += y[i] }
        tm /= n; ym /= n
        var sxx = 0.0
        var sxy = 0.0
        for (i in 0 until n) {
            val dt = t[i] - tm
            sxx += dt * dt
            sxy += dt * (y[i] - ym)
        }
        if (sxx < 1e-9) return null
        val slope = sxy / sxx
        val intercept = ym - slope * tm
        var sse = 0.0
        for (i in 0 until n) {
            val r = y[i] - (intercept + slope * t[i])
            sse += r * r
        }
        return LinearFitResult(slope, intercept, sqrt(sse / (n - 2) / sxx))
    }
}
