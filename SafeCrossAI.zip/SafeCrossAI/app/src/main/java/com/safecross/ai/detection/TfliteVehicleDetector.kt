package com.safecross.ai.detection

import android.content.Context
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/**
 * Real on-device detector (TensorFlow Lite). If the model file is missing or its tensors do not match the
 * profile, the detector reports [isReady] = false with a reason and NEVER produces fake detections.
 */
class TfliteVehicleDetector(
    context: Context,
    private val modelAssetName: String = DEFAULT_MODEL_ASSET,
    @Volatile var minConfidence: Float = 0.5f,
    private val profile: ModelProfile = ModelProfile.EFFICIENTDET_LITE0,
    numThreads: Int = 3,
) : VehicleDetector {

    private var interpreter: Interpreter? = null
    private var preprocessor: ImagePreprocessor? = null
    private var maxDetections = 0
    private var boxesOut: Array<Array<FloatArray>> = emptyArray()
    private var classesOut: Array<FloatArray> = emptyArray()
    private var scoresOut: Array<FloatArray> = emptyArray()
    private var countOut = FloatArray(1)

    /** True if the tensors at classesIndex/scoresIndex were found to be the other way round (export-dependent). */
    private var outputsSwapped = false

    override var unavailableReason: String? = null
        private set
    override val isReady: Boolean get() = interpreter != null

    init {
        try {
            val model = loadModel(context)
            val interp = Interpreter(model, Interpreter.Options().apply { setNumThreads(numThreads) })
            val problem = validate(interp)
            if (problem != null) {
                interp.close()
                unavailableReason = "Model is incompatible: $problem"
            } else {
                val shape = interp.getInputTensor(0).shape() // [1,H,W,3]
                preprocessor = ImagePreprocessor(shape[2], shape[1])
                maxDetections = interp.getOutputTensor(profile.scoresIndex).shape()[1]
                boxesOut = Array(1) { Array(maxDetections) { FloatArray(4) } }
                classesOut = Array(1) { FloatArray(maxDetections) }
                scoresOut = Array(1) { FloatArray(maxDetections) }
                interpreter = interp
            }
        } catch (e: FileNotFoundException) {
            unavailableReason = "Model file '$modelAssetName' is missing from app/src/main/assets (see docs/MODEL.md)"
        } catch (t: Throwable) {
            unavailableReason = "Model failed to load: ${t.javaClass.simpleName}: ${t.message}"
        }
    }

    private fun loadModel(context: Context): MappedByteBuffer =
        context.assets.openFd(modelAssetName).use { fd ->
            FileInputStream(fd.fileDescriptor).channel.use { ch ->
                ch.map(FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength)
            }
        }

    /** Returns a description of the first mismatch, or null if the model matches the profile. */
    private fun validate(interp: Interpreter): String? {
        if (interp.inputTensorCount != 1) return "expected 1 input tensor, found ${interp.inputTensorCount}"
        val input = interp.getInputTensor(0)
        val s = input.shape()
        if (s.size != 4 || s[0] != 1 || s[3] != 3) return "input shape must be [1,H,W,3], found ${s.toList()}"
        if (input.dataType() != DataType.UINT8) return "input must be UINT8, found ${input.dataType()}"
        if (interp.outputTensorCount != 4) return "expected 4 output tensors, found ${interp.outputTensorCount}"
        for (i in 0 until 4) {
            if (interp.getOutputTensor(i).dataType() != DataType.FLOAT32) return "output $i must be FLOAT32"
        }
        val boxes = interp.getOutputTensor(profile.boxesIndex).shape()
        val classes = interp.getOutputTensor(profile.classesIndex).shape()
        val scores = interp.getOutputTensor(profile.scoresIndex).shape()
        val count = interp.getOutputTensor(profile.countIndex).shape()
        if (boxes.size != 3 || boxes[0] != 1 || boxes[2] != 4) return "boxes tensor shape ${boxes.toList()} != [1,N,4]"
        if (classes.size != 2 || classes[1] != boxes[1]) return "classes tensor shape ${classes.toList()} mismatch"
        if (scores.size != 2 || scores[1] != boxes[1]) return "scores tensor shape ${scores.toList()} mismatch"
        if (count.size != 1 || count[0] != 1) return "count tensor shape ${count.toList()} != [1]"
        return null
    }

    override fun detect(input: DetectorInput): List<Detection> {
        val interp = interpreter ?: throw ModelUnavailableException(unavailableReason ?: "detector not ready")
        val buffer = preprocessor!!.process(input.bitmap, input.rotationDegrees)
        val outputs = HashMap<Int, Any>(4)
        outputs[profile.boxesIndex] = boxesOut
        outputs[profile.classesIndex] = classesOut
        outputs[profile.scoresIndex] = scoresOut
        outputs[profile.countIndex] = countOut
        interp.runForMultipleInputsOutputs(arrayOf<Any>(buffer), outputs)
        return parse()
    }

    private fun parse(): List<Detection> {
        val countF = countOut[0]
        if (countF.isNaN() || countF < 0f || countF > maxDetections + 0.5f) {
            throw DetectorOutputException("implausible detection count $countF")
        }
        val n = countF.toInt().coerceIn(0, maxDetections)

        // Export-dependent tensor order: decide which [1,N] tensor holds scores and which holds classes.
        val id = ModelOutputInterpreter.identifyScoresAndClasses(
            classesOut[0].copyOf(n), scoresOut[0].copyOf(n), defaultAIsClasses = !outputsSwapped,
        ) ?: throw DetectorOutputException("cannot tell scores from classes in model output")
        outputsSwapped = id.first == 0 // first argument (classesOut) is actually the scores
        val classes = if (outputsSwapped) scoresOut[0] else classesOut[0]
        val scores = if (outputsSwapped) classesOut[0] else scoresOut[0]

        for (i in 0 until n) {
            if (scores[i].isNaN() || scores[i] < 0f || scores[i] > 1.0001f) {
                throw DetectorOutputException("implausible score ${scores[i]}")
            }
            for (v in boxesOut[0][i]) {
                if (v.isNaN() || v < -0.25f || v > 1.25f) throw DetectorOutputException("implausible box coordinate $v")
            }
        }
        return ModelOutputInterpreter.decode(boxesOut[0], classes, scores, n, minConfidence, profile.vehicleClassIds)
    }

    override fun close() {
        interpreter?.close()
        interpreter = null
        preprocessor?.close()
        preprocessor = null
    }

    companion object {
        const val DEFAULT_MODEL_ASSET = "efficientdet_lite0.tflite"
    }
}
