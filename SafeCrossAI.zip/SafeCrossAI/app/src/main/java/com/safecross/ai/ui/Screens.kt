package com.safecross.ai.ui

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.camera.view.PreviewView
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.safecross.ai.calibration.CalibrationStatus
import com.safecross.ai.calibration.Point2
import com.safecross.ai.camera.CameraProblem
import com.safecross.ai.permissions.findActivity
import com.safecross.ai.pipeline.AnalysisUiState
import com.safecross.ai.risk.HealthIssue
import com.safecross.ai.risk.RiskConfig
import com.safecross.ai.risk.RiskState
import com.safecross.ai.settings.AppLanguage
import java.util.Locale

private val BigButtonHeight: Dp = 64.dp

@Composable
private fun BigButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, danger: Boolean = false) {
    Button(
        onClick = onClick,
        modifier = modifier.height(BigButtonHeight),
        colors = if (danger) ButtonDefaults.buttonColors(containerColor = Palette.DangerBg, contentColor = Color.White)
        else ButtonDefaults.buttonColors(containerColor = Palette.Accent, contentColor = Color.White),
    ) { Text(text, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun ReminderCard(strings: Strings) {
    Text(
        strings.reminder,
        fontSize = 15.sp, lineHeight = 21.sp, color = Palette.Ink,
        modifier = Modifier.fillMaxWidth().background(Color(0xFFEEEEEE), RoundedCornerShape(10.dp)).padding(12.dp),
    )
}

// ---------------------------------------------------------------------------------------------------------------
@Composable
fun HomeScreen(vm: MainViewModel, strings: Strings) {
    val context = LocalContext.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text(strings.appName, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(strings.homeIntro, fontSize = 18.sp, lineHeight = 26.sp)
        if (!vm.modelFilePresent) {
            Text(
                strings.modelMissing, fontSize = 17.sp, color = Color.White, lineHeight = 24.sp,
                modifier = Modifier.fillMaxWidth().background(Palette.DangerBg, RoundedCornerShape(10.dp)).padding(12.dp),
            )
        }
        ReminderCard(strings)
        BigButton(strings.start, { vm.startMonitoring() }, Modifier.fillMaxWidth())
        OutlinedButton(onClick = { vm.openSettings() }, modifier = Modifier.fillMaxWidth().height(BigButtonHeight)) {
            Text(strings.settings, fontSize = 20.sp)
        }
        OutlinedButton(
            onClick = { context.findActivity()?.finish() },
            modifier = Modifier.fillMaxWidth().height(BigButtonHeight),
        ) { Text(strings.closeApp, fontSize = 20.sp) }
    }
}

// ---------------------------------------------------------------------------------------------------------------
/** Camera preview + overlay, sized to the 3:4 portrait preview so overlay coordinates match the image. */
@Composable
private fun CameraArea(
    vm: MainViewModel,
    ui: AnalysisUiState,
    strings: Strings,
    modifier: Modifier,
    calibrationPoints: List<Point2> = emptyList(),
    onTap: ((Float, Float) -> Unit)? = null,
) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val previewView = remember {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FIT_CENTER
            keepScreenOn = true
        }
    }
    DisposableEffect(owner, previewView) {
        vm.startCamera(owner, previewView)
        onDispose { vm.stopCamera() }
    }
    BoxWithConstraints(modifier.background(Color.Black), contentAlignment = Alignment.Center) {
        val w = minOf(maxWidth, maxHeight * 0.75f)
        Box(Modifier.size(w, w * 4f / 3f)) {
            AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
            CameraOverlay(ui, strings, calibrationPoints, onTap)
        }
    }
}

@Composable
fun CameraScreen(vm: MainViewModel, strings: Strings) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val cameraProblem by vm.cameraProblem.collectAsStateWithLifecycle()

    val trackingOrModelFailure = HealthIssue.TRACKING_FAILURE in ui.issues || HealthIssue.MODEL_UNAVAILABLE in ui.issues
    val relevantVehicle = ui.assessment?.evaluations?.isNotEmpty() == true

    Column(Modifier.fillMaxSize()) {
        StatusBanner(ui.risk, strings.riskLabel(ui.risk))
        CameraArea(vm, ui, strings, Modifier.weight(1f).fillMaxWidth())
        Column(
            Modifier.fillMaxWidth().background(Palette.Paper).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            if (cameraProblem != null) Warning(strings.cameraProblem)
            if (trackingOrModelFailure) Warning(strings.trackingFailure)
            if (!vm.modelFilePresent) Warning(strings.modelMissing)
            if (ui.assessment?.calibrationMissingForDecision == true) Warning(strings.calibrationMissing)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Pill(strings.analysisLabel(ui.analysisStatus), Color(0xFF263238), Color.White)
                Pill("${strings.calibrationWord}: ${strings.calibrationLabel(ui.calibration)}", Color(0xFFCFD8DC), Color.Black)
            }
            Text(strings.ttcText(ui.dominantTtc, relevantVehicle), fontSize = 16.sp, lineHeight = 22.sp)
            Text(strings.speedText(ui.dominantSpeed, ui.calibration), fontSize = 16.sp)
            Text(String.format(Locale.US, strings.vehiclesFormat, ui.tracks.count { it.confirmed }), fontSize = 14.sp)
            ui.issues.filter { it != HealthIssue.TRACKING_FAILURE && it != HealthIssue.MODEL_UNAVAILABLE }
                .takeIf { it.isNotEmpty() }
                ?.let { Text(it.joinToString(" • ") { i -> strings.issueLabel(i) }, fontSize = 14.sp) }
            Text(strings.reminder, fontSize = 13.sp, lineHeight = 18.sp, color = Color(0xFF424242))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                ToggleChip(strings.sound, settings.soundEnabled) { on -> vm.updateSettings { it.copy(soundEnabled = on) } }
                ToggleChip(strings.vibration, settings.vibrationEnabled) { on -> vm.updateSettings { it.copy(vibrationEnabled = on) } }
                OutlinedButton(onClick = { vm.openCalibration() }, modifier = Modifier.height(48.dp)) {
                    Text(strings.calibrate, fontSize = 16.sp)
                }
            }
            BigButton(strings.stop, { vm.goHome() }, Modifier.fillMaxWidth(), danger = true)
        }
    }
}

@Composable
private fun Warning(text: String) {
    Text(
        text, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.Black, lineHeight = 21.sp,
        modifier = Modifier.fillMaxWidth().background(Palette.UncertainBg, RoundedCornerShape(8.dp)).padding(8.dp),
    )
}

@Composable
private fun ToggleChip(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 15.sp)
        Spacer(Modifier.size(6.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

// ---------------------------------------------------------------------------------------------------------------
@Composable
fun CalibrationScreen(vm: MainViewModel, strings: Strings) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val state by vm.calibration.state.collectAsStateWithLifecycle()
    var widthText by remember { mutableStateOf("") }
    var lengthText by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val calibrating = state.status == CalibrationStatus.CALIBRATING
    val pointCount = state.points.size

    Column(Modifier.fillMaxSize().background(Palette.Paper)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(strings.calTitle, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(strings.calIntro, fontSize = 14.sp, lineHeight = 20.sp)
            Text(
                when {
                    !calibrating -> state.lastFailure?.let { strings.failureText(it) } ?: ""
                    pointCount < 4 -> String.format(Locale.US, strings.calTapNext, strings.calPointNames[pointCount])
                    else -> strings.calAllPoints
                },
                fontSize = 17.sp, fontWeight = FontWeight.Bold,
            )
        }
        CameraArea(
            vm, ui, strings, Modifier.weight(1f).fillMaxWidth(),
            calibrationPoints = state.points,
            onTap = if (calibrating && pointCount < 4) ({ x: Float, y: Float -> vm.addCalibrationPoint(x, y) }) else null,
        )
        Column(
            Modifier.fillMaxWidth().heightIn(max = 300.dp).verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = widthText, onValueChange = { widthText = it }, label = { Text(strings.calWidth, fontSize = 12.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true,
                    modifier = Modifier.weight(1f),
                )
                OutlinedTextField(
                    value = lengthText, onValueChange = { lengthText = it }, label = { Text(strings.calLength, fontSize = 12.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true,
                    modifier = Modifier.weight(1f),
                )
            }
            error?.let { Warning(it) }
            Text(strings.calLimitations, fontSize = 12.sp, lineHeight = 17.sp)
            if (!calibrating) {
                BigButton(strings.calRestart, { error = null; vm.beginCalibration() }, Modifier.fillMaxWidth())
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.undoCalibrationPoint() }, Modifier.weight(1f).height(52.dp)) { Text(strings.calUndo) }
                    OutlinedButton(onClick = { vm.beginCalibration() }, Modifier.weight(1f).height(52.dp)) { Text(strings.calReset) }
                }
                BigButton(
                    strings.calConfirm,
                    {
                        val w = parseDecimal(widthText)
                        val l = parseDecimal(lengthText)
                        error = if (w == null || l == null) {
                            strings.calFailDimensions
                        } else {
                            vm.confirmCalibration(w, l)?.let { strings.failureText(it) }
                        }
                    },
                    Modifier.fillMaxWidth(),
                )
            }
            OutlinedButton(onClick = { vm.leaveCalibration() }, Modifier.fillMaxWidth().height(52.dp)) { Text(strings.calCancel) }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
@Composable
fun SettingsScreen(vm: MainViewModel, strings: Strings) {
    val s by vm.settings.collectAsStateWithLifecycle()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(strings.settings, fontSize = 28.sp, fontWeight = FontWeight.Bold)

        SectionTitle(strings.language)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for ((lang, label) in listOf(AppLanguage.ARABIC to strings.langAr, AppLanguage.ENGLISH to strings.langEn)) {
                val selected = s.language == lang
                if (selected) BigButton(label, {}, Modifier.weight(1f))
                else OutlinedButton(
                    onClick = { vm.updateSettings { it.copy(language = lang) } },
                    modifier = Modifier.weight(1f).height(BigButtonHeight),
                ) { Text(label, fontSize = 20.sp) }
            }
        }

        SwitchRow(strings.sound, s.soundEnabled) { on -> vm.updateSettings { it.copy(soundEnabled = on) } }
        SwitchRow(strings.vibration, s.vibrationEnabled) { on -> vm.updateSettings { it.copy(vibrationEnabled = on) } }

        SliderRow(strings.minConfidence, s.minConfidence, 0.2f..0.9f, "%.2f") { v -> vm.updateSettings { it.copy(minConfidence = v) } }
        SliderRow(strings.crossingWidth, s.crossingWidthM, 2f..30f, "%.0f") { v -> vm.updateSettings { it.copy(crossingWidthM = v) } }
        SliderRow(strings.walkingSpeed, s.walkingSpeedMps, 0.5f..1.4f, "%.1f") { v -> vm.updateSettings { it.copy(walkingSpeedMps = v) } }
        SliderRow(strings.safetyMargin, s.safetyMarginS, 2f..10f, "%.0f") { v -> vm.updateSettings { it.copy(safetyMarginS = v) } }
        Text(
            String.format(Locale.US, strings.requiredTimeFormat, s.toRiskConfig().requiredClearTimeS),
            fontSize = 15.sp, lineHeight = 21.sp, fontWeight = FontWeight.Bold,
        )

        SectionTitle(strings.zoneTitle)
        SliderRow(strings.zoneLeft, s.zoneLeft, 0f..0.45f, "%.2f") { v -> vm.updateSettings { it.copy(zoneLeft = v) } }
        SliderRow(strings.zoneRight, s.zoneRight, 0.55f..1f, "%.2f") { v -> vm.updateSettings { it.copy(zoneRight = v) } }
        SliderRow(strings.zoneTop, s.zoneTop, 0.4f..0.95f, "%.2f") { v -> vm.updateSettings { it.copy(zoneTop = v) } }

        SectionTitle(strings.calibrationWord)
        Text(strings.settingsCalibrationNote, fontSize = 15.sp, lineHeight = 21.sp)
        Text(strings.settingsPrivacyNote, fontSize = 15.sp, lineHeight = 21.sp)
        ReminderCard(strings)
        BigButton(strings.back, { vm.goHome() }, Modifier.fillMaxWidth())
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 18.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, fmt: String, onChange: (Float) -> Unit) {
    var local by remember(value) { mutableStateOf(value) }
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Text(String.format(Locale.US, fmt, local), fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        Slider(value = local, onValueChange = { local = it }, valueRange = range, onValueChangeFinished = { onChange(local) })
    }
}
