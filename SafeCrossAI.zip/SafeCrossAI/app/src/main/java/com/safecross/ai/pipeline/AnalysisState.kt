package com.safecross.ai.pipeline

import com.safecross.ai.calibration.CalibrationStatus
import com.safecross.ai.detection.NormBox
import com.safecross.ai.detection.VehicleClass
import com.safecross.ai.risk.ConflictZone
import com.safecross.ai.risk.HealthIssue
import com.safecross.ai.risk.MotionClass
import com.safecross.ai.risk.RiskAssessment
import com.safecross.ai.risk.RiskState
import com.safecross.ai.risk.SpeedEstimate
import com.safecross.ai.risk.TimeToConflict

enum class AnalysisStatus { STARTING, ANALYZING, SLOW, UNSTABLE_CAMERA, UNRELIABLE }

data class TrackUi(
    val id: Int,
    val vehicleClass: VehicleClass,
    val box: NormBox,
    val confidence: Float,
    val motion: MotionClass,
    val isLost: Boolean,
    val confirmed: Boolean,
    /** Non-null ONLY when a valid calibration produced it. */
    val speed: SpeedEstimate?,
)

data class AnalysisUiState(
    /** The state shown to the user (after anti-flicker smoothing). */
    val risk: RiskState = RiskState.UNCERTAIN,
    val assessment: RiskAssessment? = null,
    val tracks: List<TrackUi> = emptyList(),
    val calibration: CalibrationStatus = CalibrationStatus.NOT_CALIBRATED,
    val analysisStatus: AnalysisStatus = AnalysisStatus.STARTING,
    val dominantTtc: TimeToConflict? = null,
    val dominantSpeed: SpeedEstimate? = null,
    val issues: List<HealthIssue> = emptyList(),
    val modelUnavailableReason: String? = null,
    val latencyMs: Long = 0,
    val fps: Float = 0f,
    val zone: ConflictZone = ConflictZone(),
)
