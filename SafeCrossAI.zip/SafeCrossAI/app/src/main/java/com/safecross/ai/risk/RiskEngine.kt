package com.safecross.ai.risk

/**
 * Pure, side-effect-free crossing risk evaluation. The most dangerous vehicle decides the state.
 *
 * Principles (all covered by unit tests):
 *  - A vehicle only counts as "potentially clear" if its time-to-conflict comes from a VALID CALIBRATION and
 *    its conservative lower bound exceeds the required crossing time. Image-only estimates never clear.
 *  - Unknown / unstable / stale information is never treated as safe.
 *  - Perception problems (model, camera, light, blur, lag, tracking) force at least UNCERTAIN, but never
 *    hide a DANGER found at the same time.
 *  - Stale data is penalised: the lower bound is reduced by the age of the last analysed frame.
 */
class RiskEngine {

    fun evaluate(input: RiskInput, config: RiskConfig): RiskAssessment {
        val required = config.requiredClearTimeS
        val issues = healthIssues(input.health, config)
        val elapsedS = input.health.lastFrameAgeMs.coerceIn(0L, 60_000L) / 1000.0

        val evaluations = input.threats.mapNotNull { evaluateThreat(it, required, elapsedS) }

        val worstThreat = evaluations.maxOfOrNull { it.state.severity } ?: 0
        val state = when {
            worstThreat == RiskState.DANGER.severity -> RiskState.DANGER
            issues.isNotEmpty() || worstThreat == RiskState.UNCERTAIN.severity -> RiskState.UNCERTAIN
            else -> RiskState.POTENTIALLY_CLEAR
        }
        val dominant = evaluations
            .filter { it.state.severity == worstThreat }
            .minByOrNull { it.marginS ?: Double.NEGATIVE_INFINITY }
        return RiskAssessment(state, issues, evaluations, dominant, required)
    }

    fun healthIssues(h: PerceptionHealth, c: RiskConfig): List<HealthIssue> = buildList {
        if (!h.modelReady) add(HealthIssue.MODEL_UNAVAILABLE)
        if (h.lastFrameAgeMs > c.maxFrameAgeMs) add(HealthIssue.NO_RECENT_FRAME)
        if (h.inferenceLatencyMs > c.maxInferenceLatencyMs) add(HealthIssue.ANALYSIS_SLOW)
        if (!h.cameraStable) add(HealthIssue.CAMERA_UNSTABLE)
        when (h.sceneQuality) {
            SceneQuality.TOO_DARK -> add(HealthIssue.TOO_DARK)
            SceneQuality.TOO_BRIGHT -> add(HealthIssue.TOO_BRIGHT)
            SceneQuality.BLURRY -> add(HealthIssue.BLURRY)
            SceneQuality.OK -> Unit
        }
        if (h.thermalSevere) add(HealthIssue.THERMAL_THROTTLING)
        if (h.trackingFailed) add(HealthIssue.TRACKING_FAILURE)
    }

    /** Returns null when the vehicle is irrelevant to the crossing decision. */
    private fun evaluateThreat(t: ThreatInput, required: Double, elapsedS: Double): ThreatEvaluation? {
        fun eval(state: RiskState, reason: RiskReason, margin: Double? = null) =
            ThreatEvaluation(t, state, reason, margin)

        if (!t.trackConfirmed) {
            return if (t.inOrOverlapsZone) eval(RiskState.UNCERTAIN, RiskReason.UNCONFIRMED_TRACK_IN_ZONE) else null
        }
        if (t.isLost) {
            return when {
                t.motion == MotionClass.APPROACHING -> eval(RiskState.DANGER, RiskReason.LOST_APPROACHING_TRACK)
                t.motion == MotionClass.RECEDING -> null
                t.motion == MotionClass.STATIONARY && !t.inOrOverlapsZone -> null
                else -> eval(RiskState.UNCERTAIN, RiskReason.LOST_TRACK_IN_ZONE)
            }
        }
        return when (t.motion) {
            MotionClass.RECEDING -> null
            MotionClass.STATIONARY ->
                if (t.inOrOverlapsZone) eval(RiskState.UNCERTAIN, RiskReason.STATIONARY_IN_ZONE) else null
            MotionClass.UNKNOWN -> eval(RiskState.UNCERTAIN, RiskReason.UNKNOWN_MOTION)
            MotionClass.APPROACHING -> {
                val ttc = t.ttc
                if (ttc == null) {
                    if (t.inOrOverlapsZone) eval(RiskState.DANGER, RiskReason.APPROACHING_IN_ZONE_UNKNOWN_TTC)
                    else eval(RiskState.UNCERTAIN, RiskReason.APPROACHING_UNKNOWN_TTC)
                } else {
                    val effectiveLower = ttc.lowerBoundS - elapsedS
                    val margin = effectiveLower - required
                    when {
                        effectiveLower < required -> eval(RiskState.DANGER, RiskReason.BELOW_SAFETY_MARGIN, margin)
                        ttc.basis != TtcBasis.CALIBRATED_METRIC ->
                            eval(RiskState.UNCERTAIN, RiskReason.TTC_UNCALIBRATED, margin)
                        else -> eval(RiskState.POTENTIALLY_CLEAR, RiskReason.TTC_ABOVE_MARGIN_CALIBRATED, margin)
                    }
                }
            }
        }
    }
}
