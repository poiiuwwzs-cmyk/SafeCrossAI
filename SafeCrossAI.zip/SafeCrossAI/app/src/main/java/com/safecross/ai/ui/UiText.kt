package com.safecross.ai.ui

import com.safecross.ai.calibration.CalibrationFailure
import com.safecross.ai.calibration.CalibrationStatus
import com.safecross.ai.calibration.InvalidReason
import com.safecross.ai.detection.VehicleClass
import com.safecross.ai.pipeline.AnalysisStatus
import com.safecross.ai.risk.HealthIssue
import com.safecross.ai.risk.MotionClass
import com.safecross.ai.risk.RiskState
import com.safecross.ai.risk.SpeedEstimate
import com.safecross.ai.risk.TimeToConflict
import com.safecross.ai.risk.TtcBasis
import java.util.Locale

fun Strings.riskLabel(s: RiskState) = when (s) {
    RiskState.DANGER -> danger
    RiskState.UNCERTAIN -> uncertain
    RiskState.POTENTIALLY_CLEAR -> clear
}

fun Strings.calibrationLabel(s: CalibrationStatus) = when (s) {
    CalibrationStatus.NOT_CALIBRATED -> calNot
    CalibrationStatus.CALIBRATING -> calIn
    CalibrationStatus.CALIBRATED -> calOk
    CalibrationStatus.INVALID -> calBad
}

fun Strings.analysisLabel(s: AnalysisStatus) = when (s) {
    AnalysisStatus.STARTING -> statusStarting
    AnalysisStatus.ANALYZING -> statusAnalyzing
    AnalysisStatus.SLOW -> statusSlow
    AnalysisStatus.UNSTABLE_CAMERA -> statusUnstable
    AnalysisStatus.UNRELIABLE -> statusUnreliable
}

fun Strings.className(c: VehicleClass) = when (c) {
    VehicleClass.CAR -> car
    VehicleClass.BUS -> bus
    VehicleClass.TRUCK -> truck
    VehicleClass.MOTORCYCLE -> motorcycle
    VehicleClass.BICYCLE -> bicycle
}

fun Strings.motionLabel(m: MotionClass, isLost: Boolean) = if (isLost) lost else when (m) {
    MotionClass.APPROACHING -> approaching
    MotionClass.RECEDING -> receding
    MotionClass.STATIONARY -> stationary
    MotionClass.UNKNOWN -> unknownMotion
}

fun Strings.issueLabel(i: HealthIssue) = when (i) {
    HealthIssue.MODEL_UNAVAILABLE -> issueModel
    HealthIssue.NO_RECENT_FRAME -> issueNoFrame
    HealthIssue.ANALYSIS_SLOW -> issueSlow
    HealthIssue.CAMERA_UNSTABLE -> issueUnstable
    HealthIssue.TOO_DARK -> issueDark
    HealthIssue.TOO_BRIGHT -> issueBright
    HealthIssue.BLURRY -> issueBlurry
    HealthIssue.THERMAL_THROTTLING -> issueThermal
    HealthIssue.TRACKING_FAILURE -> issueTracking
}

fun Strings.ttcText(ttc: TimeToConflict?, hasRelevantVehicle: Boolean): String = when {
    ttc == null -> if (hasRelevantVehicle) ttcUnknown else ttcNone
    else -> String.format(Locale.US, ttcFormat, ttc.nominalS, ttc.lowerBoundS) + " " +
        if (ttc.basis == TtcBasis.CALIBRATED_METRIC) ttcCalibrated else ttcImageBased
}

/** Speed is shown only when a valid calibration produced it; otherwise the fixed "unavailable" text. */
fun Strings.speedText(speed: SpeedEstimate?, status: CalibrationStatus): String =
    if (speed != null && status == CalibrationStatus.CALIBRATED) {
        String.format(Locale.US, speedFormat, speed.kmh, speed.uncertaintyKmh)
    } else speedUnavailable

fun Strings.failureText(f: CalibrationFailure) = when (f) {
    CalibrationFailure.NEED_FOUR_POINTS -> calFailNeedFour
    CalibrationFailure.INVALID_DIMENSIONS -> calFailDimensions
    CalibrationFailure.BAD_ORDER_OR_GEOMETRY -> calFailGeometry
    CalibrationFailure.DEGENERATE -> calFailDegenerate
    CalibrationFailure.CAMERA_MOVED_DURING_CALIBRATION -> calFailMoved
    CalibrationFailure.GYRO_UNAVAILABLE -> calFailGyro
}

fun Strings.invalidText(r: InvalidReason?) = when (r) {
    InvalidReason.CAMERA_MOVED -> calInvalidMoved
    InvalidReason.EXPIRED -> calInvalidExpired
    InvalidReason.GYRO_LOST -> calInvalidGyro
    null -> calBad
}

/** Accepts Western and Arabic-Indic digits and both decimal separators. */
fun parseDecimal(text: String): Double? {
    val normalized = buildString {
        for (ch in text.trim()) append(
            when (ch) {
                in '\u0660'..'\u0669' -> '0' + (ch - '\u0660')
                in '\u06F0'..'\u06F9' -> '0' + (ch - '\u06F0')
                ',', '\u066B', '\u060C' -> '.'
                else -> ch
            },
        )
    }
    return normalized.toDoubleOrNull()?.takeIf { it.isFinite() }
}
