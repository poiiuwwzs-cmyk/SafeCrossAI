package com.safecross.ai.tracking

import com.safecross.ai.detection.Detection

data class TrackerParams(
    val minIou: Float = 0.15f,
    val minHitsToConfirm: Int = 3,
    /** A track not matched for this long is considered "lost" (coasting). */
    val lostAfterMs: Long = 400,
    /** Confirmed tracks are kept (as lost) this long so a vehicle hidden by occlusion is not forgotten at once. */
    val retentionMs: Long = 2000,
    val tentativeRetentionMs: Long = 500,
    val maxHistory: Int = 60,
)

/**
 * IoU tracker with constant-velocity prediction: each existing track predicts its box, detections are
 * greedily matched in descending IoU order. Class-agnostic matching (detector class flicker is common);
 * the track class is a running majority vote.
 */
class VehicleTracker(
    val params: TrackerParams = TrackerParams(),
    private val estimator: TrackMotionEstimator = TrackMotionEstimator(),
) {
    private val tracks = ArrayList<Track>()
    private var nextId = 1

    val activeTracks: List<Track> get() = tracks

    fun isConfirmed(t: Track) = t.hits >= params.minHitsToConfirm
    fun isLost(t: Track, nowMs: Long) = nowMs - t.lastDetectionMs > params.lostAfterMs

    fun update(detections: List<Detection>, nowMs: Long): List<Track> {
        data class Pair(val trackIdx: Int, val detIdx: Int, val iou: Float)
        val pairs = ArrayList<Pair>()
        for (ti in tracks.indices) {
            val predicted = tracks[ti].predictBox(nowMs)
            for (di in detections.indices) {
                val iou = predicted.iou(detections[di].box)
                if (iou >= params.minIou) pairs.add(Pair(ti, di, iou))
            }
        }
        pairs.sortByDescending { it.iou }
        val trackUsed = BooleanArray(tracks.size)
        val detUsed = BooleanArray(detections.size)
        for (p in pairs) {
            if (trackUsed[p.trackIdx] || detUsed[p.detIdx]) continue
            trackUsed[p.trackIdx] = true
            detUsed[p.detIdx] = true
            val track = tracks[p.trackIdx]
            track.add(detections[p.detIdx], nowMs)
            track.imageMotion = estimator.estimate(track.history)
        }
        for (di in detections.indices) {
            if (!detUsed[di]) tracks.add(Track(nextId++, detections[di], nowMs, params.maxHistory))
        }
        tracks.removeAll { t ->
            val age = nowMs - t.lastDetectionMs
            if (isConfirmed(t)) age > params.retentionMs else age > params.tentativeRetentionMs
        }
        return tracks
    }

    fun reset() {
        tracks.clear()
        nextId = 1
    }
}
