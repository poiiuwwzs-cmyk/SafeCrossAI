package com.safecross.ai.ui

import android.graphics.Paint as AndroidPaint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.safecross.ai.calibration.Point2
import com.safecross.ai.pipeline.AnalysisUiState
import com.safecross.ai.risk.MotionClass
import com.safecross.ai.risk.RiskState

object Palette {
    val DangerBg = Color(0xFFB00020)
    val UncertainBg = Color(0xFFFFC400)
    val ClearBg = Color(0xFF00574B)
    val Ink = Color(0xFF111111)
    val Paper = Color(0xFFFFFFFF)
    val Accent = Color(0xFF0D47A1)
}

/** Large status banner. State is conveyed by text AND a distinct glyph shape, never by colour alone. */
@Composable
fun StatusBanner(state: RiskState, text: String) {
    val (bg, fg) = when (state) {
        RiskState.DANGER -> Palette.DangerBg to Color.White
        RiskState.UNCERTAIN -> Palette.UncertainBg to Color.Black
        RiskState.POTENTIALLY_CLEAR -> Palette.ClearBg to Color.White
    }
    Row(
        Modifier.fillMaxWidth().background(bg).padding(12.dp)
            .semantics(mergeDescendants = true) { liveRegion = LiveRegionMode.Assertive },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        StateGlyph(state, fg, Modifier.size(44.dp))
        Spacer(Modifier.width(12.dp))
        Text(text, color = fg, fontSize = 22.sp, fontWeight = FontWeight.Bold, lineHeight = 29.sp)
    }
}

/** DANGER = cross in a circle; UNCERTAIN = triangle with "!"; POTENTIALLY_CLEAR = ring with a dot (not a tick: it is not "safe"). */
@Composable
fun StateGlyph(state: RiskState, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val stroke = Stroke(width = w * 0.09f, cap = StrokeCap.Round)
        when (state) {
            RiskState.DANGER -> {
                drawCircle(color, radius = w * 0.46f, style = stroke)
                drawLine(color, Offset(w * 0.3f, w * 0.3f), Offset(w * 0.7f, w * 0.7f), strokeWidth = w * 0.11f, cap = StrokeCap.Round)
                drawLine(color, Offset(w * 0.7f, w * 0.3f), Offset(w * 0.3f, w * 0.7f), strokeWidth = w * 0.11f, cap = StrokeCap.Round)
            }
            RiskState.UNCERTAIN -> {
                val p = Path().apply {
                    moveTo(w * 0.5f, w * 0.06f); lineTo(w * 0.96f, w * 0.92f); lineTo(w * 0.04f, w * 0.92f); close()
                }
                drawPath(p, color, style = stroke)
                drawLine(color, Offset(w * 0.5f, w * 0.34f), Offset(w * 0.5f, w * 0.64f), strokeWidth = w * 0.09f, cap = StrokeCap.Round)
                drawCircle(color, radius = w * 0.05f, center = Offset(w * 0.5f, w * 0.78f))
            }
            RiskState.POTENTIALLY_CLEAR -> {
                drawCircle(color, radius = w * 0.46f, style = stroke)
                drawCircle(color, radius = w * 0.1f, center = Offset(w * 0.5f, w * 0.5f))
            }
        }
    }
}

@Composable
fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(120.dp))
        Text(value, fontSize = 16.sp, modifier = Modifier.weight(1f))
    }
}

@Composable
fun Pill(text: String, background: Color, foreground: Color) {
    Text(
        text, color = foreground, fontSize = 15.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.background(background, RoundedCornerShape(50)).padding(horizontal = 12.dp, vertical = 6.dp),
    )
}

@Composable
fun SectionTitle(text: String) = Text(text, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))

/**
 * Overlay drawn exactly over the camera preview (same aspect ratio), so normalized coordinates line up.
 * Draws the conflict zone, tracked vehicle boxes with IDs, and optional calibration points. [onTap] receives
 * normalized (0..1) coordinates and is only attached while calibrating.
 */
@Composable
fun CameraOverlay(
    ui: AnalysisUiState,
    strings: Strings,
    calibrationPoints: List<Point2> = emptyList(),
    onTap: ((Float, Float) -> Unit)? = null,
) {
    val textPaint = remember {
        AndroidPaint().apply { isAntiAlias = true; textSize = 34f; color = android.graphics.Color.WHITE; isFakeBoldText = true }
    }
    val tapModifier = if (onTap != null) {
        Modifier.pointerInput(onTap) {
            detectTapGestures { off -> onTap(off.x / size.width, off.y / size.height) }
        }
    } else Modifier

    Canvas(Modifier.fillMaxSize().then(tapModifier)) {
        val w = size.width
        val h = size.height
        // conflict zone (dashed)
        val z = ui.zone
        drawRect(
            color = Color.White,
            topLeft = Offset(z.left * w, z.top * h),
            size = Size((z.right - z.left) * w, (1f - z.top) * h),
            style = Stroke(width = 3f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(22f, 14f))),
        )
        for (t in ui.tracks) {
            val danger = t.motion == MotionClass.APPROACHING || t.isLost
            val color = when {
                !t.confirmed -> Color(0xFFB0BEC5)
                danger -> Color(0xFFFF1744)
                else -> Color(0xFF64B5F6)
            }
            val tl = Offset(t.box.left * w, t.box.top * h)
            val sz = Size(t.box.width * w, t.box.height * h)
            drawRect(color, tl, sz, style = Stroke(width = if (danger) 7f else 4f,
                pathEffect = if (t.isLost) PathEffect.dashPathEffect(floatArrayOf(12f, 10f)) else null))
            drawLabel("#${t.id} ${strings.className(t.vehicleClass)} · ${strings.motionLabel(t.motion, t.isLost)}", tl.x, tl.y, color, textPaint)
        }
        // calibration points
        if (calibrationPoints.isNotEmpty()) {
            for (i in 0 until calibrationPoints.size - 1) {
                drawLine(Color.Yellow, calibrationPoints[i].toOffset(w, h), calibrationPoints[i + 1].toOffset(w, h), strokeWidth = 4f)
            }
            if (calibrationPoints.size == 4) {
                drawLine(Color.Yellow, calibrationPoints[3].toOffset(w, h), calibrationPoints[0].toOffset(w, h), strokeWidth = 4f)
            }
            calibrationPoints.forEachIndexed { i, p ->
                val c = p.toOffset(w, h)
                drawCircle(Color.Yellow, radius = 18f, center = c)
                drawCircle(Color.Black, radius = 18f, center = c, style = Stroke(width = 3f))
                drawIntoCanvas {
                    val black = AndroidPaint().apply { isAntiAlias = true; textSize = 26f; color = android.graphics.Color.BLACK; isFakeBoldText = true }
                    it.nativeCanvas.drawText("${i + 1}", c.x - 7f, c.y + 9f, black)
                }
            }
        }
    }
}

private fun Point2.toOffset(w: Float, h: Float) = Offset((x * w).toFloat(), (y * h).toFloat())

private fun DrawScope.drawLabel(text: String, x: Float, y: Float, bg: Color, paint: AndroidPaint) {
    val tw = paint.measureText(text)
    val th = paint.textSize + 10f
    val top = (y - th).coerceAtLeast(0f)
    drawRect(bg, Offset(x, top), Size(tw + 16f, th))
    drawIntoCanvas { it.nativeCanvas.drawText(text, x + 8f, top + th - 10f, paint) }
}
