package com.safecross.ai.risk

/**
 * Pedestrian and safety parameters. Defaults are deliberately conservative and UNVALIDATED.
 *
 * Required clear time = (startDelay + width / walkingSpeed) * (1 + uncertaintyFraction) + safetyMargin.
 * With defaults (8 m, 1.0 m/s, 2 s, 20 %, 3 s): (2 + 8) * 1.2 + 3 = 15 s.
 * The walking speed is a slow walk on purpose; the engine never assumes running.
 */
data class RiskConfig(
    val crossingWidthM: Double = 8.0,
    val walkingSpeedMps: Double = 1.0,
    val startDelayS: Double = 2.0,
    val crossingUncertaintyFraction: Double = 0.2,
    val safetyMarginS: Double = 3.0,
    val maxFrameAgeMs: Long = 700,
    val maxInferenceLatencyMs: Long = 600,
) {
    init {
        require(crossingWidthM > 0.0) { "crossing width must be positive" }
        require(walkingSpeedMps > 0.0) { "walking speed must be positive" }
        require(startDelayS >= 0.0 && crossingUncertaintyFraction >= 0.0 && safetyMarginS >= 0.0)
    }

    val crossingDurationS: Double
        get() = (startDelayS + crossingWidthM / walkingSpeedMps) * (1.0 + crossingUncertaintyFraction)

    val requiredClearTimeS: Double get() = crossingDurationS + safetyMarginS
}

/** Heuristic thresholds for perception health. UNVALIDATED: tune with recorded footage. */
data class PerceptionThresholds(
    val maxShakeRateRadPerS: Double = 0.35,
    val calibrationMaxRotationRad: Double = 0.026, // about 1.5 degrees
    val calibrationMaxAgeMs: Long = 3 * 60_000L,
    val minMeanLuma: Double = 30.0,
    val maxMeanLuma: Double = 230.0,
    val minLaplacianVariance: Double = 4.0,
    val baseFrameIntervalMs: Long = 100,
)
