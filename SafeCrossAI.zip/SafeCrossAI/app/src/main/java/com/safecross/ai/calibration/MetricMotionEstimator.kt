package com.safecross.ai.calibration

import com.safecross.ai.tracking.LinearFit
import com.safecross.ai.tracking.Observation
import kotlin.math.max

/** Ground-plane position (m) and velocity (m/s) of a vehicle in the calibrated road frame. */
data class MetricMotion(val x: Double, val y: Double, val vx: Double, val vy: Double, val sigmaV: Double)

/**
 * Projects the bottom-centre of each bounding box (assumed ground contact point) through the road homography
 * and fits a straight line through the metric positions.
 *
 * Returns null (=> no real-world numbers) unless ALL hold: the newest box is not cut by the frame border, enough
 * unclipped samples cover enough time, and the newest position lies inside the region where the homography is
 * still meaningful (Y in [-5 m, 3L], X in [-W, 2W]). Bounding-box bottoms are not exact ground contacts
 * (shadows, occlusion, detector jitter); the caller widens the uncertainty accordingly.
 */
class MetricMotionEstimator(
    private val windowMs: Long = 1500,
    private val minSamples: Int = 5,
    private val minSpanMs: Long = 800,
    private val sigmaFloorMps: Double = 0.15,
    private val groundVisibleBelow: Float = 0.98f,
) {
    fun estimate(history: List<Observation>, cal: RoadPlaneCalibration): MetricMotion? {
        if (history.size < minSamples) return null
        val last = history.last()
        if (last.box.bottom >= groundVisibleBelow) return null
        val usable = history.filter { last.timestampMs - it.timestampMs <= windowMs && it.box.bottom < groundVisibleBelow }
        if (usable.size < minSamples) return null
        if (usable.last().timestampMs - usable.first().timestampMs < minSpanMs) return null

        val ts = ArrayList<Double>(usable.size)
        val xs = ArrayList<Double>(usable.size)
        val ys = ArrayList<Double>(usable.size)
        for (o in usable) {
            val w = cal.imageToWorld(o.box.centerX.toDouble(), o.box.bottom.toDouble()) ?: continue
            ts.add((o.timestampMs - last.timestampMs) / 1000.0)
            xs.add(w.x); ys.add(w.y)
        }
        if (ts.size < minSamples) return null
        val t = ts.toDoubleArray()
        val fx = LinearFit.fit(t, xs.toDoubleArray()) ?: return null
        val fy = LinearFit.fit(t, ys.toDoubleArray()) ?: return null

        val x = fx.intercept
        val y = fy.intercept
        if (y < -5.0 || y > 3.0 * cal.lengthM) return null
        if (x < -cal.widthM || x > 2.0 * cal.widthM) return null
        return MetricMotion(x, y, fx.slope, fy.slope, max(max(fx.slopeSigma, fy.slopeSigma), sigmaFloorMps))
    }
}
