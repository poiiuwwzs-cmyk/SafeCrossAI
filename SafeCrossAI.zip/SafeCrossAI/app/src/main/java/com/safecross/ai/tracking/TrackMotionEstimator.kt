package com.safecross.ai.tracking

import kotlin.math.ln
import kotlin.math.max

/**
 * Least-squares image-space motion over a sliding window. Standard errors are floored because box jitter
 * from the detector is never zero; flooring keeps the downstream "significance" tests conservative.
 *
 * Boxes cut by the frame border are excluded from the scale fit (their size is truncated, which would
 * bias the apparent growth rate low), but still contribute to the centre-velocity fit.
 */
class TrackMotionEstimator(
    private val windowMs: Long = 2000,
    private val minSamples: Int = 4,
    private val minSpanMs: Long = 400,
    private val lateralSigmaFloor: Double = 0.005,
    private val scaleSigmaFloor: Double = 0.01,
) {
    fun estimate(history: List<Observation>): ImageMotion? {
        if (history.size < minSamples) return null
        val lastT = history.last().timestampMs
        val window = history.filter { lastT - it.timestampMs <= windowMs }
        if (window.size < minSamples) return null
        val span = lastT - window.first().timestampMs
        if (span < minSpanMs) return null

        val t = DoubleArray(window.size) { (window[it].timestampMs - lastT) / 1000.0 }
        val cx = DoubleArray(window.size) { window[it].box.centerX.toDouble() }
        val cy = DoubleArray(window.size) { window[it].box.centerY.toDouble() }
        val fx = LinearFit.fit(t, cx) ?: return null
        val fy = LinearFit.fit(t, cy) ?: return null

        val clean = window.filter { !it.box.touchesBorder() && it.box.height > 1e-4f }
        var scaleRate: Double? = null
        var scaleSigma: Double? = null
        if (clean.size >= minSamples && clean.last().timestampMs - clean.first().timestampMs >= minSpanMs) {
            val ts = DoubleArray(clean.size) { (clean[it].timestampMs - lastT) / 1000.0 }
            val ls = DoubleArray(clean.size) { ln(clean[it].box.height.toDouble()) }
            LinearFit.fit(ts, ls)?.let {
                scaleRate = it.slope
                scaleSigma = max(it.slopeSigma, scaleSigmaFloor)
            }
        }
        return ImageMotion(
            vx = fx.slope,
            vy = fy.slope,
            lateralSigma = max(max(fx.slopeSigma, fy.slopeSigma), lateralSigmaFloor),
            scaleRate = scaleRate,
            scaleRateSigma = scaleSigma,
            spanMs = span,
            samples = window.size,
        )
    }
}
