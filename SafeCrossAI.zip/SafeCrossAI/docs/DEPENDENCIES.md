# Dependency choices

| Component | Version | Notes |
|---|---|---|
| Android Gradle Plugin | 8.10.0 | Requires Gradle ≥ 8.11.1 (wrapper properties use 8.11.1) and JDK 17. Checked against the AGP 8.10 release notes. |
| Kotlin / Compose compiler plugin | 2.1.21 | `org.jetbrains.kotlin.plugin.compose` matches the Kotlin version. |
| compileSdk / targetSdk / minSdk | 35 / 35 / 26 | minSdk 26 gives adaptive icons, `VibrationEffect`, no desugaring needs. |
| Compose BOM | 2025.05.00 | material3 / ui / foundation from the BOM. |
| CameraX | 1.4.2 | `ImageProxy.toBitmap()`, `ResolutionSelector`, `UseCaseGroup` + `ViewPort`. |
| TensorFlow Lite | 2.16.1 | see docs/MODEL.md for the LiteRT note. |
| Lifecycle / Activity / DataStore / Coroutines | 2.9.0 / 1.10.1 / 1.1.7 / 1.10.2 | |
| JUnit | 4.13.2 | unit tests are plain JVM tests; no Android classes in tested code. |

## What was and was not verified
* Verified (by reading the official release notes): AGP 8.10 ↔ Gradle 8.11.1 ↔ API 35.
* **Not verified**: a real `./gradlew` resolution/build. The sandbox this was written in had no network, no Android SDK,
  no Gradle and no Kotlin compiler. Expect that the first build on your machine may need small fixes.
* No analytics, ads, crash-reporting or network libraries are included; the manifest has no INTERNET permission.
