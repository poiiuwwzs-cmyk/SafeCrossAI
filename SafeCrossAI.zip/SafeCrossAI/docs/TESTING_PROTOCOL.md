# Manual testing protocol (controlled environment only)

Do **not** test by crossing real roads. Use pre-recorded footage played on a screen in front of the phone, or film from a
safe, fenced position (footbridge, balcony) and replay. Log: scenario, expected state, observed state, timestamps.

For every scenario record: the shown state, the status chips, TTC text, speed text, and whether any state ever read
"no clear danger" while a vehicle was approaching (this is a **fail**).

| # | Scenario | Expected |
|---|---|---|
| 1 | Daylight, empty road | after ~2 s: "no clear danger" + reminder (never "safe") |
| 2 | Daylight, single car approaching | DANGER while closer than the required time; never "clear" without calibration |
| 3 | Same, with valid calibration and a vehicle of known speed (GPS-logged) | speed within the displayed ± range; else the model/limits are wrong, report it |
| 4 | Car moving away | ignored (no DANGER) |
| 5 | Stationary car in the zone / outside the zone | WAIT / ignored |
| 6 | Several vehicles, one fast | worst vehicle decides; its box is highlighted |
| 7 | Night / dusk, headlights | WAIT ("too dark") or DANGER; never "clear" without detections you trust |
| 8 | Occlusion: approaching car passes behind a bus | lost-track → DANGER (then WAIT), never "clear" |
| 9 | Camera shake (walk with the phone) | "camera unstable" + WAIT; calibration becomes invalid |
| 10 | Low frame rate (cover half the CPU, hot phone, throttle) | "analysis is slow" + WAIT |
| 11 | Camera blocked/frozen (cover lens, kill camera) | WAIT within ~1 s; DANGER state is not hidden |
| 12 | Model file removed | home-screen warning + failure message + WAIT |
| 13 | Permission denied (twice) | explanation + "open app settings" button |
| 14 | App backgrounded and resumed | returns to home; calibration cleared |
| 15 | Language switch Arabic ↔ English | RTL ↔ LTR, all labels, exact required Arabic texts |

Calibration check: measure a rectangle on the ground with a tape, calibrate, then drive/roll an object of known speed through it
and compare. Repeat at 3 distances. Only trust a speed display if error is acceptable for your use; otherwise leave calibration off.

Unit tests passing proves the logic matches its specification. It does **not** validate real-world safety.
