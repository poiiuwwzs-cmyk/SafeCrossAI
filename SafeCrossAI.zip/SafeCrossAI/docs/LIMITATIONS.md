# Limitations and safety

**SafeCross AI is an experimental aid. It has not been validated for pedestrian safety and must never replace looking both
ways, obeying signals and your own judgement.** The app never says a crossing is safe; the best state is
"no clear danger detected".

## What the three numbers mean
1. *Apparent image motion* (box growth, sideways drift): a hint only.
2. *Approximate relative time to the conflict zone*: from looming (`τ = 1 / (d ln h / dt)`, constant speed head-on assumption) or
   from the sideways gap. Always labelled "image-only, not calibrated". It can raise DANGER but can **never** produce
   "no clear danger" while a vehicle is approaching.
3. *Calibrated speed / distance*: only with a valid road-plane calibration; shown with ± uncertainty, otherwise
   "السرعة الحقيقية غير متاحة".

## Calibration limits
Flat road assumed; fixed camera required (gyroscope-checked, ≥ 1.5° rotation invalidates it, 3 min expiry, cleared on stop);
no lens-distortion correction; accuracy limited by tap precision and the measured rectangle; bounding-box bottom is not the
true ground contact (shadows, occlusion); error grows quickly with distance; slopes and curves break the model. A phone without a
gyroscope cannot calibrate and is treated as "camera stability unknown" (WAIT).

## Other limits
* Only traffic in the camera's field of view is considered. Vehicles from behind, turning vehicles, silent bicycles, and
  vehicles that appear suddenly are not covered.
* Night, rain, glare, dirt on the lens, tiny/far vehicles and occlusion degrade detection; the app only partly senses this
  (mean brightness, blur, lag).
* Thresholds in `RiskConfig`, `PerceptionThresholds`, `MotionThresholds` are **heuristic and unvalidated**.
* Uncertain data is reported as WAIT, so the app will often say "wait" in busy or noisy scenes. That is intentional.
* Detection runs ~10 fps at best on mid-range phones (not measured here).

## Not yet validated in the real world
Detection quality per class and lighting · class-id mapping on the actual model file · looming TTC accuracy · calibrated
speed accuracy against a known-speed vehicle · shake/blur/dark thresholds · latency, battery and thermal behaviour ·
Arabic text rendering on small/old devices · accessibility with TalkBack.
