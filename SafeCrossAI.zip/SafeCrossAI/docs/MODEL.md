# Detection model

The app does **not** ship a model file. Without it the app starts, says so on the home screen, and stays in
WAIT / UNCERTAIN: it never invents detections.

## Required artifact
| | |
|---|---|
| File name | `app/src/main/assets/efficientdet_lite0.tflite` |
| Model | EfficientDet-Lite0, COCO 2017, *detection* variant: input `uint8 [1,320,320,3]`, 4 float outputs (boxes `[1,N,4]` as ymin,xmin,ymax,xmax normalized; classes `[1,N]`; scores `[1,N]`; count `[1]`) |
| Sources (pick one) | Kaggle Models: `tensorflow/efficientdet` → TFLite → `lite0-detection` (the former TF Hub model `tensorflow/efficientdet/lite0/detection/1`), or Hugging Face `litert-community/efficientdet` (Files and versions → the Lite0 uint8 detection `.tflite`) |
| License | Apache License 2.0 as stated on those pages when this project was set up. **Re-check the license on the page you download from before you distribute the app.** COCO annotations are CC BY 4.0. |

Download in a browser (Kaggle may ask you to sign in and accept terms), copy the `.tflite` to the path above
(rename if needed). `scripts/fetch_model.sh <url> ` can also fetch a URL you have verified yourself and prints its SHA-256.
No URL is hard-coded on purpose: file names on those sites change and I could not verify them offline.

## Compatibility checks done by the app (`TfliteVehicleDetector`)
* input must be `UINT8 [1,H,W,3]`, exactly 4 `FLOAT32` outputs with matching shapes, otherwise the detector reports
  "Model is incompatible: ..." and stays unavailable;
* the `classes`/`scores` tensors are told apart at run time (`ModelOutputInterpreter.identifyScoresAndClasses`) because
  export order differs between builds; if neither assignment is plausible the frame is rejected;
* NaN / out-of-range scores or boxes reject the frame (the pipeline then reports "tracking failure").

## Class ids (UNVERIFIED on a device)
Vehicles are taken from the 0-based COCO label map where 0 = person: 1 bicycle, 2 car, 3 motorcycle, 5 bus, 7 truck.
These ids are identical in the 80-class and the 90-class (with `???` gaps) maps. Verify once with real footage: point
the phone at a parked car and a bus and check the on-screen class names.

## Known risks
* EfficientDet-Lite0 is small; far, small, or night-time vehicles are missed. That is a perception limit the risk
  engine cannot see: *no detection ≠ no vehicle*.
* `org.tensorflow:tensorflow-lite:2.16.1` is the last release under that name; Google continues it as LiteRT
  (`com.google.ai.edge.litert`). For Google Play targeting Android 15+ devices check 16 KB page-size support of the native libraries
  and consider migrating. Not verified here.
