#!/usr/bin/env bash
# Cloud build for SafeCross AI (GitHub Actions or Codespaces). Everything that is claimed in the summary is
# only written AFTER the corresponding command really succeeded.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
REPO="${GITHUB_WORKSPACE:-$PWD}"
OUT="$REPO/out"
SUMMARY="${GITHUB_STEP_SUMMARY:-/dev/null}"
mkdir -p "$OUT/wrapper"
cd "$ROOT"
say() { echo "$*" | tee -a "$SUMMARY"; }

# ---- 1. Real model (never a fake one) -------------------------------------------------------------------
MODEL="app/src/main/assets/efficientdet_lite0.tflite"
URL="https://huggingface.co/litert-community/efficientdet/resolve/main/efficientdet_lite0_detection.tflite"
mkdir -p "$(dirname "$MODEL")"
if [ ! -f "$MODEL" ]; then
  say "Downloading EfficientDet-Lite0 (Apache-2.0, litert-community on Hugging Face)..."
  curl -fL --retry 3 -o "$MODEL" "$URL"
fi
SIZE=$(stat -c%s "$MODEL")
MAGIC=$(dd if="$MODEL" bs=1 skip=4 count=4 2>/dev/null || true)
if [ "$MAGIC" != "TFL3" ] || [ "$SIZE" -lt 3000000 ] || [ "$SIZE" -gt 8000000 ]; then
  say "MODEL CHECK FAILED: size=$SIZE magic='$MAGIC' (expected a ~4.5 MB TFLite flatbuffer 'TFL3'). Not building."
  rm -f "$MODEL"; exit 1
fi
sha256sum "$MODEL" | tee "$OUT/model.sha256"
say "Model OK: $SIZE bytes, TFLite header present (tensor layout is checked by the app at run time)."

# ---- 2. Android SDK ---------------------------------------------------------------------------------------
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [ -n "$SDK" ]; then
  echo "sdk.dir=$SDK" > local.properties
  SDKM="$SDK/cmdline-tools/latest/bin/sdkmanager"
  if [ -x "$SDKM" ]; then
    yes | "$SDKM" --licenses >/dev/null 2>&1 || true
    "$SDKM" "platforms;android-35" "build-tools;35.0.0" >/dev/null 2>&1 || say "warning: sdkmanager could not install platform 35 (Gradle will try itself)"
  fi
else
  say "warning: ANDROID_HOME is not set"
fi

# ---- 3. Gradle wrapper (generated, never faked) ------------------------------------------------------
if [ ! -f gradle/wrapper/gradle-wrapper.jar ]; then
  TMP="$(mktemp -d)"
  (cd "$TMP" && gradle wrapper --gradle-version 8.11.1 --no-daemon -q)
  cp "$TMP/gradlew" "$TMP/gradlew.bat" .
  cp "$TMP/gradle/wrapper/gradle-wrapper.jar" gradle/wrapper/
  chmod +x gradlew
fi
cp gradlew gradlew.bat gradle/wrapper/gradle-wrapper.jar "$OUT/wrapper/"

# ---- 4. Build the debug APK ----------------------------------------------------------------------------
set +e
./gradlew assembleDebug --no-daemon --stacktrace 2>&1 | tee "$OUT/build.log"
BUILD=${PIPESTATUS[0]}
set -e
if [ "$BUILD" -ne 0 ]; then
  {
    echo "### Build FAILED. Copy the block below and send it to Claude"
    echo '```'
    grep -E "^e: |error:|What went wrong|Execution failed|Could not |Unresolved reference" -A2 "$OUT/build.log" | head -150 || true
    echo '```'
  } >> "$SUMMARY"
  exit 1
fi
APK="app/build/outputs/apk/debug/app-debug.apk"
cp "$APK" "$OUT/SafeCrossAI-debug.apk"
say "Debug APK built: $(stat -c%s "$OUT/SafeCrossAI-debug.apk") bytes."

# ---- 5. Unit tests (a failing test does not block the APK, but it is reported) ---------------------
set +e
./gradlew testDebugUnitTest --no-daemon --continue 2>&1 | tee "$OUT/test.log"
TESTS=${PIPESTATUS[0]}
set -e
cp -r app/build/reports/tests "$OUT/test-report" 2>/dev/null || true
TEST_LINE=$(python3 - <<'PY'
import glob, xml.etree.ElementTree as ET
t = f = e = s = 0; bad = []
for p in glob.glob("app/build/test-results/testDebugUnitTest/*.xml"):
    r = ET.parse(p).getroot()
    t += int(r.get("tests", 0)); f += int(r.get("failures", 0)); e += int(r.get("errors", 0)); s += int(r.get("skipped", 0))
    for c in r.iter("testcase"):
        if c.find("failure") is not None or c.find("error") is not None:
            bad.append(c.get("classname", "") + "." + c.get("name", ""))
line = f"Unit tests: {t} run, {f} failed, {e} errors, {s} skipped"
if t == 0: line = "Unit tests: NO RESULTS FOUND (tests did not run)"
print(line + ("" if not bad else " | FAILED: " + ", ".join(bad[:15])))
PY
)
say "$TEST_LINE (gradle exit code $TESTS)"
echo "$TEST_LINE" > "$OUT/test-summary.txt"

# ---- 6. Publish the APK as a Release (direct .apk download on a phone) ---------------------------------
if command -v gh >/dev/null 2>&1 && [ -n "${GH_TOKEN:-}" ] && [ -n "${GITHUB_REPOSITORY:-}" ]; then
  TAG="build-${GITHUB_RUN_NUMBER:-local}"
  if gh release create "$TAG" "$OUT/SafeCrossAI-debug.apk" --repo "$GITHUB_REPOSITORY" \
       --title "SafeCross AI debug #${GITHUB_RUN_NUMBER:-local}" --prerelease \
       --notes "Debug APK (experimental, not validated for real-world safety). $TEST_LINE"; then
    say "Release created: tag $TAG (open the repo > Releases to download the .apk)"
  else
    say "Release step failed; download the APK from the run's Artifacts instead."
  fi
fi
