#!/bin/sh
# Downloads a .tflite model from a URL YOU have verified (see docs/MODEL.md) into the app assets.
# Usage: scripts/fetch_model.sh <url>
set -eu
URL="${1:-}"
if [ -z "$URL" ]; then
  echo "Usage: $0 <url-of-efficientdet-lite0-detection.tflite>" >&2
  echo "See docs/MODEL.md for legal sources and licence notes." >&2
  exit 2
fi
DEST="$(dirname "$0")/../app/src/main/assets/efficientdet_lite0.tflite"
mkdir -p "$(dirname "$DEST")"
curl -fL --retry 3 -o "$DEST" "$URL"
SIZE=$(wc -c < "$DEST")
if [ "$SIZE" -lt 1000000 ]; then
  echo "Downloaded file is only $SIZE bytes: probably an HTML page, not a model. Removing." >&2
  rm -f "$DEST"; exit 1
fi
echo "Saved $DEST ($SIZE bytes)"
if command -v sha256sum >/dev/null 2>&1; then sha256sum "$DEST"; fi
