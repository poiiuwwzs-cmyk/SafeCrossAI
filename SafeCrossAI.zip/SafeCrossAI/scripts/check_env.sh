#!/bin/sh
# Prints what is needed to build SafeCross AI and whether it is present.
echo "== JDK (need 17+)";   java -version 2>&1 | head -1 || echo "MISSING"
echo "== ANDROID_HOME";     echo "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-NOT SET}}"
echo "== platform 35";      ls "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/nonexistent}}/platforms/android-35" >/dev/null 2>&1 && echo ok || echo "MISSING (sdkmanager 'platforms;android-35' 'build-tools;35.0.0')"
echo "== gradle wrapper";   [ -f "$(dirname "$0")/../gradlew" ] && echo ok || echo "MISSING: run 'gradle wrapper --gradle-version 8.11.1' once (or open in Android Studio)"
echo "== model file";       [ -f "$(dirname "$0")/../app/src/main/assets/efficientdet_lite0.tflite" ] && echo ok || echo "MISSING (docs/MODEL.md)"
